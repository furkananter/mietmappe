import { copyFile, mkdir } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const modules = join(root, "node_modules");
const target = join(root, "public", "ocr");

const ASSETS = [
  ["tesseract.js/dist/worker.min.js", "worker.min.js"],
  ["tesseract.js-core/tesseract-core-lstm.wasm.js", "core/tesseract-core-lstm.wasm.js"],
  ["tesseract.js-core/tesseract-core-simd-lstm.wasm.js", "core/tesseract-core-simd-lstm.wasm.js"],
  ["tesseract.js-core/tesseract-core-relaxedsimd-lstm.wasm.js", "core/tesseract-core-relaxedsimd-lstm.wasm.js"],
  ["@tesseract.js-data/deu/4.0.0_best_int/deu.traineddata.gz", "lang/deu.traineddata.gz"],
];

try {
  for (const [source, destination] of ASSETS) {
    const out = join(target, destination);
    await mkdir(dirname(out), { recursive: true });
    await copyFile(join(modules, source), out);
  }
  console.log(`Copied ${ASSETS.length} OCR assets to public/ocr`);
} catch (error) {
  console.error("Could not copy OCR assets. Run npm install first.", error);
  process.exit(1);
}
