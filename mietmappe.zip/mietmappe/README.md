# Mietmappe

Redact, watermark and bundle your rental application documents before they reach a German landlord. Everything runs in your browser.

**Live demo:** https://furkananter.github.io/mietmappe/

![Findings detected in a sample payslip](docs/screenshots/findings-light.png)

## Why

Landlords in Germany routinely ask for payslips, ID copies and bank data, often by email and to dozens of applicants at once. Every extra copy of an unredacted document is a risk. Mietmappe helps you share only what is needed, and a visible watermark ties each copy to one specific application, so a leaked file can be traced and is useless for anything else.

## Features

- Drag and drop PDFs and images
- Manual redaction by drawing boxes over any page
- On-device OCR that suggests what to hide: IBAN (mod-97 check), German tax ID (checksum), social security number (check digit), BIC, MRZ lines, CAN and passport numbers (by context), email, phone, religion and church tax, personnel and insurance numbers
- Per-document checklists of what to black out
- German watermark naming the recipient and purpose
- Flattened PDF export with no text layer, so redacted content cannot be copied out
- Sent log with CSV export
- Undo/redo and keyboard shortcuts
- English and German UI, light and dark theme

| Dark, German checklist | Empty state, dark |
| --- | --- |
| ![Checklist in German, dark theme](docs/screenshots/checklist-dark-de.png) | ![Empty state, dark theme](docs/screenshots/empty-dark.png) |

## Privacy model

- Nothing is uploaded. There is no backend.
- OCR runs locally with tesseract.js. The German LSTM model (about 1.3 MB) and the wasm core are served from the same origin, never from a third-party CDN.
- The sent log is stored in `localStorage` only, in your browser.

## Tech stack

React 19, Vite, strict TypeScript, Tailwind CSS v4, Radix UI primitives, pdf.js for rendering, pdf-lib for export, tesseract.js for OCR, Vitest.

## Architecture

```
src/
  detection/      pure detectors and validators (IBAN, tax ID, SSN, ...)
  ocr/            tesseract.js engine wrapper and self-hosted asset URLs
  i18n/           EN/DE messages, translator, locale provider
  guides/         per-document-kind redaction checklists
  samples/        canvas-drawn sample documents for the demo
  hooks/          scanning, history, export, log, keyboard shortcuts
  lib/            PDF building, watermarking, file handling, CSV
  components/ui/  small design-system primitives
```

## Getting started

```bash
npm install
npm run dev      # copies OCR assets to public/ocr, then starts Vite
npm test
npm run build
```

Requires Node 20 or newer.

## Testing

The detection logic is pure and unit-tested with Vitest (`npm test`), including checksum validators and context rules.

## Deploy

`.github/workflows/deploy.yml` builds the app and publishes `dist` to GitHub Pages on every push to `main`, with `BASE_PATH` set to the repository name. In the repository settings, set Pages source to "GitHub Actions". `ci.yml` runs typecheck, tests and build on every push and pull request.

## Auf Deutsch

Mietmappe schwärzt und kennzeichnet Unterlagen für die Wohnungsbewerbung, bevor sie an Vermieter gehen. Eine lokale Texterkennung schlägt sensible Daten wie IBAN, Steuer-ID oder Sozialversicherungsnummer zur Schwärzung vor. Ein Wasserzeichen verknüpft jede Kopie mit genau einer Bewerbung. Alles läuft im Browser, es wird nichts hochgeladen.

## License

MIT, see [LICENSE](LICENSE).
