import { type DrawingSurface, createSurface, drawRule, writeText } from "./canvasPage";

const WIDTH = 1240;
const HEIGHT = 1754;
const LEFT = 110;
const RIGHT = WIDTH - 110;
const ROW = 44;

const PERSONAL_DATA: readonly [string, string][] = [
  ["Personalnummer", "004711"],
  ["Geburtsdatum", "17.08.1989"],
  ["Steuer-ID", "47 158 236 906"],
  ["Steuerklasse", "1"],
  ["Konfession", "ev"],
  ["SV-Nummer", "65 170889 M 007"],
  ["Krankenkasse", "Beispiel BKK"],
  ["E-Mail", "max.mustermann@example.com"],
  ["Telefon", "+49 30 1234 5678"],
];

const EARNINGS: readonly [string, string][] = [
  ["Grundgehalt", "4.200,00"],
  ["Gesamtbrutto", "4.200,00"],
  ["Lohnsteuer", "-712,41"],
  ["Kirchensteuer", "-57,00"],
  ["Krankenversicherung", "-357,00"],
  ["Rentenversicherung", "-390,60"],
  ["Arbeitslosenversicherung", "-54,60"],
  ["Pflegeversicherung", "-71,05"],
];

function drawHeader(surface: DrawingSurface): void {
  const { context } = surface;
  writeText(context, "Musterfirma GmbH", LEFT, 150, 40, { weight: 600 });
  writeText(context, "Beispielweg 5, 10117 Berlin", LEFT, 196, 26, { color: "#555555" });
  writeText(context, "Entgeltabrechnung", RIGHT, 150, 40, { weight: 600, align: "right" });
  writeText(context, "September 2026", RIGHT, 196, 26, { align: "right", color: "#555555" });
  drawRule(context, LEFT, 240, RIGHT - LEFT);

  writeText(context, "Max Mustermann", LEFT, 320, 30, { weight: 600 });
  writeText(context, "Musterstraße 1", LEFT, 362, 28);
  writeText(context, "10115 Berlin", LEFT, 402, 28);
}

function drawRows(surface: DrawingSurface, rows: readonly [string, string][], top: number, alignValue: CanvasTextAlign) {
  const valueX = alignValue === "right" ? RIGHT : LEFT + 330;
  rows.forEach(([label, value], index) => {
    const y = top + index * ROW;
    writeText(surface.context, label, LEFT, y, 28, { color: "#444444" });
    writeText(surface.context, value, valueX, y, 28, { align: alignValue });
  });
  return top + rows.length * ROW;
}

export default function drawPayslip(): DrawingSurface {
  const surface = createSurface(WIDTH, HEIGHT);
  const { context } = surface;
  drawHeader(surface);

  writeText(context, "Persönliche Daten", LEFT, 480, 30, { weight: 600 });
  const afterPersonal = drawRows(surface, PERSONAL_DATA, 530, "left");

  drawRule(context, LEFT, afterPersonal, RIGHT - LEFT);
  writeText(context, "Bezüge und Abzüge", LEFT, afterPersonal + 60, 30, { weight: 600 });
  const afterEarnings = drawRows(surface, EARNINGS, afterPersonal + 110, "right");

  drawRule(context, LEFT, afterEarnings - 10, RIGHT - LEFT);
  writeText(context, "Nettoverdienst", LEFT, afterEarnings + 44, 30, { weight: 600 });
  writeText(context, "2.557,34 EUR", RIGHT, afterEarnings + 44, 30, { weight: 600, align: "right" });

  writeText(context, "Auszahlung", LEFT, afterEarnings + 124, 30, { weight: 600 });
  writeText(context, "IBAN DE89 3704 0044 0532 0130 00", LEFT, afterEarnings + 174, 28);
  writeText(context, "BIC COBADEFFXXX", LEFT, afterEarnings + 220, 28);

  writeText(context, "Beispieldokument für Mietmappe. Alle Daten sind erfunden.", WIDTH / 2, HEIGHT - 80, 22, {
    align: "center",
    color: "#888888",
  });
  return surface;
}
