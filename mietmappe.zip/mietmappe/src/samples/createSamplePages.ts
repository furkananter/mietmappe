import type { DocumentPage } from "../types";
import { surfaceToPage } from "./canvasPage";
import drawPayslip from "./drawPayslip";
import drawResidenceCard from "./drawResidenceCard";

const FONTS = ['400 28px "IBM Plex Sans"', '600 28px "IBM Plex Sans"', '400 38px "IBM Plex Mono"'];

export default async function createSamplePages(): Promise<DocumentPage[]> {
  await Promise.all(FONTS.map((font) => document.fonts.load(font)));
  return Promise.all([
    surfaceToPage(drawPayslip(), "Beispiel_Gehaltsabrechnung.png", "payslip"),
    surfaceToPage(drawResidenceCard(), "Beispiel_Aufenthaltstitel.png", "residencePermit"),
  ]);
}
