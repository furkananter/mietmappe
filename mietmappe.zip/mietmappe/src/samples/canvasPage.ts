import canvasToBlob from "../lib/canvasToBlob";
import createId from "../lib/createId";
import type { DocumentKind, DocumentPage } from "../types";

export interface DrawingSurface {
  canvas: HTMLCanvasElement;
  context: CanvasRenderingContext2D;
}

export function createSurface(width: number, height: number): DrawingSurface {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas 2D context unavailable");
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, width, height);
  context.textBaseline = "alphabetic";
  return { canvas, context };
}

export function writeText(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  options: { weight?: number; align?: CanvasTextAlign; mono?: boolean; color?: string } = {},
): void {
  const family = options.mono ? '"IBM Plex Mono", "Courier New", monospace' : '"IBM Plex Sans", Arial, sans-serif';
  context.font = `${options.weight ?? 400} ${size}px ${family}`;
  context.fillStyle = options.color ?? "#111111";
  context.textAlign = options.align ?? "left";
  context.fillText(text, x, y);
}

export function drawRule(context: CanvasRenderingContext2D, x: number, y: number, width: number): void {
  context.fillStyle = "#c8c8c8";
  context.fillRect(x, y, width, 2);
}

export async function surfaceToPage(
  surface: DrawingSurface,
  sourceName: string,
  kind: DocumentKind,
): Promise<DocumentPage> {
  const blob = await canvasToBlob(surface.canvas, "image/png");
  return {
    id: createId(),
    sourceName,
    pageNumber: 1,
    imageUrl: URL.createObjectURL(blob),
    width: surface.canvas.width,
    height: surface.canvas.height,
    kind,
    redactions: [],
  };
}
