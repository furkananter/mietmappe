import { type DrawingSurface, createSurface, writeText } from "./canvasPage";

const WIDTH = 1240;
const HEIGHT = 1754;
const CARD_WIDTH = 1000;
const CARD_HEIGHT = 630;
const CARD_X = (WIDTH - CARD_WIDTH) / 2;

const FRONT_FIELDS: readonly [string, string][] = [
  ["Name", "MUSTERMANN"],
  ["Vorname", "MAX"],
  ["Art des Titels", "Blaue Karte EU"],
  ["Gültig bis", "30.09.2030"],
  ["Dokumentnummer", "Y0A12B3C4"],
];

const MRZ_LINES = [
  "IAD<<Y0A12B3C4<<<<<<<<<<<<<<<",
  "8908175M3009304UTO<<<<<<<<<<<6",
  "MUSTERMANN<<MAX<<<<<<<<<<<<<<<",
];

function drawCardFrame(surface: DrawingSurface, top: number, title: string): void {
  const { context } = surface;
  context.fillStyle = "#eef1ef";
  context.fillRect(CARD_X, top, CARD_WIDTH, CARD_HEIGHT);
  context.strokeStyle = "#9aa39e";
  context.lineWidth = 3;
  context.strokeRect(CARD_X, top, CARD_WIDTH, CARD_HEIGHT);
  writeText(context, title, CARD_X + 40, top + 64, 28, { weight: 600 });
  writeText(context, "BEISPIEL, NICHT GÜLTIG", CARD_X + CARD_WIDTH - 40, top + 64, 22, {
    align: "right",
    color: "#a33a2b",
    weight: 600,
  });
}

function drawFront(surface: DrawingSurface, top: number): void {
  const { context } = surface;
  drawCardFrame(surface, top, "Aufenthaltstitel (Vorderseite)");
  context.fillStyle = "#c9cfcb";
  context.fillRect(CARD_X + 40, top + 110, 240, 300);
  writeText(context, "Foto", CARD_X + 160, top + 270, 28, { align: "center", color: "#6b736e" });

  FRONT_FIELDS.forEach(([label, value], index) => {
    const y = top + 140 + index * 84;
    writeText(context, label, CARD_X + 330, y, 22, { color: "#555555" });
    writeText(context, value, CARD_X + 330, y + 34, 30, { weight: 600 });
  });
  writeText(context, "CAN 123456", CARD_X + CARD_WIDTH - 40, top + CARD_HEIGHT - 40, 28, { align: "right" });
}

function drawBack(surface: DrawingSurface, top: number): void {
  drawCardFrame(surface, top, "Aufenthaltstitel (Rückseite)");
  const { context } = surface;
  writeText(context, "Anmerkungen", CARD_X + 40, top + 140, 22, { color: "#555555" });
  writeText(context, "Erwerbstätigkeit erlaubt.", CARD_X + 40, top + 182, 30);
  writeText(context, "Pass-Nr. U12345678", CARD_X + 40, top + 228, 30);

  context.fillStyle = "#ffffff";
  context.fillRect(CARD_X + 30, top + 380, CARD_WIDTH - 60, 210);
  MRZ_LINES.forEach((line, index) => {
    writeText(context, line, CARD_X + 60, top + 440 + index * 60, 38, { mono: true });
  });
}

export default function drawResidenceCard(): DrawingSurface {
  const surface = createSurface(WIDTH, HEIGHT);
  writeText(surface.context, "Kopie Aufenthaltstitel, Beispieldaten", WIDTH / 2, 130, 30, {
    align: "center",
    weight: 600,
  });
  drawFront(surface, 200);
  drawBack(surface, 920);
  writeText(surface.context, "Beispieldokument für Mietmappe. Alle Daten sind erfunden.", WIDTH / 2, HEIGHT - 80, 22, {
    align: "center",
    color: "#888888",
  });
  return surface;
}
