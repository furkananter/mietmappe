import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "@fontsource/ibm-plex-mono/400.css";
import "@fontsource/ibm-plex-mono/500.css";
import "@fontsource/ibm-plex-sans/400.css";
import "@fontsource/ibm-plex-sans/500.css";
import "@fontsource/ibm-plex-sans/600.css";

import App from "./App";
import LocaleProvider from "./i18n/LocaleProvider";
import { readInitialLocale } from "./i18n/localeStorage";
import themeStore from "./theme/themeStore";
import "./index.css";

const root = document.getElementById("root");
if (!root) throw new Error("Root element missing");

themeStore.init();

const initialLocale = readInitialLocale();
document.documentElement.lang = initialLocale;

createRoot(root).render(
  <StrictMode>
    <LocaleProvider initialLocale={initialLocale}>
      <App />
    </LocaleProvider>
  </StrictMode>,
);
