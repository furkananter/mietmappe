import { MotionConfig } from "motion/react";
import { useMemo, useState } from "react";

import AppHeader from "./components/AppHeader";
import DocumentsPanel from "./components/DocumentsPanel";
import EditorStage from "./components/EditorStage";
import RightSidebar from "./components/RightSidebar";
import { TooltipProvider } from "./components/ui/tooltip";
import useApplicationExport from "./hooks/useApplicationExport";
import useApplicationLog from "./hooks/useApplicationLog";
import useDocumentPages from "./hooks/useDocumentPages";
import useKeyboardShortcuts from "./hooks/useKeyboardShortcuts";
import useSensitiveScan from "./hooks/useSensitiveScan";
import buildWatermarkText from "./lib/buildWatermarkText";
import downloadBlob from "./lib/downloadBlob";
import logToCsv from "./lib/logToCsv";
import type { NormalizedRect, Suggestion } from "./types";

const toRect = ({ x, y, width, height }: NormalizedRect): NormalizedRect => ({ x, y, width, height });

export default function App() {
  const [address, setAddress] = useState("");
  const [recipient, setRecipient] = useState("");
  const documents = useDocumentPages();
  const scanner = useSensitiveScan();
  const log = useApplicationLog();
  const exporter = useApplicationExport();
  const page = documents.selectedPage;
  const pageSuggestions = page ? (scanner.suggestions[page.id] ?? []) : [];

  const { undo, redo, selectAdjacent } = documents;
  const shortcutsRef = useKeyboardShortcuts(
    useMemo(
      () => ({ undo, redo, previousPage: () => selectAdjacent(-1), nextPage: () => selectAdjacent(1) }),
      [undo, redo, selectAdjacent],
    ),
  );

  const acceptSuggestions = (items: Suggestion[]) => {
    if (!page || items.length === 0) return;
    documents.redact(page.id, items.map(toRect));
    scanner.dismiss(page.id, items.map((item) => item.id));
  };

  const handleExport = () =>
    void exporter.runExport({ pages: documents.pages, address, recipient, onExported: log.addEntry });

  const handleExportCsv = () =>
    downloadBlob(new Blob([logToCsv(log.entries)], { type: "text/csv" }), "mietmappe_log.csv");

  return (
    <TooltipProvider delayDuration={300}>
      <MotionConfig reducedMotion="user">
        <div className="flex min-h-dvh flex-col outline-none lg:h-dvh" ref={shortcutsRef}>
          <AppHeader />
          <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[280px_minmax(0,1fr)_368px]">
            <aside className="scrollbar-thin border-b bg-card lg:min-h-0 lg:overflow-y-auto lg:border-r lg:border-b-0">
              <DocumentsPanel
                pages={documents.pages}
                selectedId={page?.id ?? null}
                suggestions={scanner.suggestions}
                isLoading={documents.isLoading}
                errors={documents.errors}
                onFiles={(files) => void documents.addFiles(files)}
                onLoadSamples={() => void documents.loadSamples()}
                onSelect={documents.select}
                onMove={documents.move}
                onRemove={documents.removePage}
              />
            </aside>

            <main className="scrollbar-thin min-w-0 bg-stage bg-dots lg:min-h-0 lg:overflow-y-auto">
              <EditorStage
                pages={documents.pages}
                page={page}
                isLoading={documents.isLoading}
                suggestions={pageSuggestions}
                wasScanned={page ? scanner.scanned[page.id] === true : false}
                scanStatus={scanner.status}
                scanError={scanner.error}
                canUndo={documents.canUndo}
                canRedo={documents.canRedo}
                onFiles={(files) => void documents.addFiles(files)}
                onLoadSamples={() => void documents.loadSamples()}
                onUndo={undo}
                onRedo={redo}
                onScan={(targets) => void scanner.scan(targets)}
                onRedact={(rects) => page && documents.redact(page.id, rects)}
                onUnredact={(redactionId) => page && documents.unredact(page.id, redactionId)}
                onAccept={acceptSuggestions}
                onDismissAll={() => page && scanner.dismiss(page.id, "all")}
              />
            </main>

            <aside className="scrollbar-thin border-t bg-card lg:min-h-0 lg:overflow-y-auto lg:border-t-0 lg:border-l">
              <RightSidebar
                page={page}
                pageCount={documents.pages.length}
                unreviewedCount={documents.pages.filter((item) => item.redactions.length === 0).length}
                address={address}
                recipient={recipient}
                watermarkPreview={buildWatermarkText(address, recipient, new Date())}
                isExporting={exporter.isExporting}
                exportError={exporter.exportError}
                logEntries={log.entries}
                logStorageError={log.storageError}
                onKindChange={documents.setKind}
                onAddressChange={setAddress}
                onRecipientChange={setRecipient}
                onExport={handleExport}
                onLogRemove={log.removeEntry}
                onLogExportCsv={handleExportCsv}
              />
            </aside>
          </div>
        </div>
      </MotionConfig>
    </TooltipProvider>
  );
}
