export const REPOSITORY_URL = "https://github.com/furkananter/mietmappe";
