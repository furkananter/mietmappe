export function taxIdCheckDigit(firstTen: string): number {
  let product = 10;
  for (const char of firstTen) {
    let sum = (Number(char) + product) % 10;
    if (sum === 0) sum = 10;
    product = (sum * 2) % 11;
  }
  const check = 11 - product;
  return check === 10 ? 0 : check;
}

export default function isValidTaxId(raw: string): boolean {
  const digits = raw.replace(/\s+/g, "");
  if (!/^[1-9]\d{10}$/.test(digits)) return false;
  return taxIdCheckDigit(digits.slice(0, 10)) === Number(digits[10]);
}
