import type { SensitiveKind } from "../types";
import isValidIban from "./isValidIban";
import isValidSocialSecurityNumber from "./isValidSocialSecurityNumber";
import isValidTaxId from "./isValidTaxId";

export interface Detector {
  kind: SensitiveKind;
  pattern: RegExp;
  validate?: (match: string) => boolean;
  lineContext?: RegExp;
  followingWords?: number;
}

const digitCount = (value: string): number => value.replace(/\D/g, "").length;

const isDocumentNumber = (value: string): boolean => digitCount(value) >= 4 && /[A-Z]/.test(value);

const isPhoneNumber = (value: string): boolean => {
  const digits = digitCount(value);
  return digits >= 9 && digits <= 15;
};

export const DETECTORS: readonly Detector[] = [
  { kind: "iban", pattern: /\bDE\d{2}(?: ?\d{4}){4} ?\d{2}\b/g, validate: isValidIban },
  { kind: "iban", pattern: /\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,3})?\b/g, validate: isValidIban },
  { kind: "bic", pattern: /\b[A-Z]{4}(?:DE|AT|CH|LU|NL|BE|FR|IT|ES|PL|TR|GB)[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b/g },
  { kind: "taxId", pattern: /\b[1-9]\d(?: ?\d{3}){3}\b/g, validate: isValidTaxId },
  { kind: "socialSecurity", pattern: /\b\d{2} ?\d{6} ?[A-Z] ?\d{2} ?\d\b/g, validate: isValidSocialSecurityNumber },
  { kind: "email", pattern: /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g },
  { kind: "phone", pattern: /(?:\+49|0049|\+90|\b0)[\d ()/-]{7,18}\d/g, validate: isPhoneNumber },
  { kind: "documentNumber", pattern: /\b\d{6}\b/g, lineContext: /\bCAN\b/ },
  {
    kind: "documentNumber",
    pattern: /\b[A-Z0-9]{8,10}\b/g,
    validate: isDocumentNumber,
    lineContext: /pass|ausweis|dokument|document|seriennummer/i,
  },
  { kind: "religion", pattern: /\b(?:Konfession|Konf|KiSt|Kirchensteuer\w*|Religion)\b/gi, followingWords: 1 },
  { kind: "personnelNumber", pattern: /\b(?:Personalnummer|Personal-Nr|Pers\.?-Nr)\b/gi, followingWords: 1 },
  {
    kind: "insuranceNumber",
    pattern: /\b(?:Krankenversicherungsnummer|Versichertennummer|KV-Nr|KVNR)\b/gi,
    followingWords: 1,
  },
];

export function isMrzLine(lineText: string): boolean {
  const compact = lineText.replace(/\s+/g, "").replace(/«/g, "<<");
  const fillers = compact.match(/</g)?.length ?? 0;
  return /^[A-Z0-9<]{20,}$/.test(compact) && fillers >= 2;
}
