import createId from "../lib/createId";
import type { OcrLine, PageSize } from "../ocr/ocrTypes";
import type { Suggestion } from "../types";
import { DETECTORS, type Detector, isMrzLine } from "./detectors";
import findLineMatches, { joinWords, type WordSpan } from "./findLineMatches";
import wordsToRect from "./wordsToRect";

interface LineInput {
  line: OcrLine;
  previousText: string;
  size: PageSize;
  makeId: () => string;
}

function targetRange(detector: Detector, span: WordSpan, wordCount: number): [number, number] | null {
  if (!detector.followingWords) return [span.first, span.last];
  const first = span.last + 1;
  const last = Math.min(wordCount - 1, span.last + detector.followingWords);
  return first <= last ? [first, last] : null;
}

function detectInLine({ line, previousText, size, makeId }: LineInput): Suggestion[] {
  const lineText = joinWords(line.words).text;
  if (isMrzLine(lineText)) {
    return [{ id: makeId(), kind: "mrz", text: lineText, ...wordsToRect(line.words, size) }];
  }

  const claimed = new Set<number>();
  const found: Suggestion[] = [];
  const contextText = `${previousText} ${lineText}`;

  for (const detector of DETECTORS) {
    if (detector.lineContext && !detector.lineContext.test(contextText)) continue;
    for (const span of findLineMatches(line.words, detector.pattern)) {
      if (detector.validate && !detector.validate(span.text)) continue;
      const range = targetRange(detector, span, line.words.length);
      if (!range) continue;
      const [first, last] = range;
      const indices = Array.from({ length: last - first + 1 }, (_, offset) => first + offset);
      if (indices.some((index) => claimed.has(index))) continue;
      indices.forEach((index) => claimed.add(index));
      const words = line.words.slice(first, last + 1);
      found.push({ id: makeId(), kind: detector.kind, text: joinWords(words).text, ...wordsToRect(words, size) });
    }
  }
  return found;
}

export default function detectSensitiveData(
  lines: OcrLine[],
  size: PageSize,
  makeId: () => string = createId,
): Suggestion[] {
  return lines.flatMap((line, index) => {
    if (line.words.length === 0) return [];
    const previous = lines[index - 1];
    const previousText = previous ? joinWords(previous.words).text : "";
    return detectInLine({ line, previousText, size, makeId });
  });
}
