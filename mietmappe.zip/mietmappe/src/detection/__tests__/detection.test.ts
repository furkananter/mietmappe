import { describe, expect, it } from "vitest";

import type { OcrLine, OcrWord } from "../../ocr/ocrTypes";
import detectSensitiveData from "../detectSensitiveData";
import { isMrzLine } from "../detectors";
import findLineMatches from "../findLineMatches";
import isValidIban from "../isValidIban";
import isValidSocialSecurityNumber from "../isValidSocialSecurityNumber";
import isValidTaxId from "../isValidTaxId";

const SIZE = { width: 1000, height: 1000 };

function line(text: string, y = 100): OcrLine {
  let x = 10;
  const words: OcrWord[] = text.split(" ").map((token) => {
    const word = { text: token, bbox: { x0: x, y0: y, x1: x + token.length * 10, y1: y + 20 } };
    x += token.length * 10 + 10;
    return word;
  });
  return { words };
}

let counter = 0;
const makeId = () => `id-${counter++}`;
const kindsOf = (text: string) => detectSensitiveData([line(text)], SIZE, makeId).map((s) => s.kind);

describe("checksums", () => {
  it("validates IBANs with mod 97", () => {
    expect(isValidIban("DE89 3704 0044 0532 0130 00")).toBe(true);
    expect(isValidIban("GB82 WEST 1234 5698 7654 32")).toBe(true);
    expect(isValidIban("DE89 3704 0044 0532 0130 01")).toBe(false);
    expect(isValidIban("DE89 3704 0044")).toBe(false);
  });

  it("validates German tax IDs", () => {
    expect(isValidTaxId("47 158 236 906")).toBe(true);
    expect(isValidTaxId("47158236905")).toBe(false);
    expect(isValidTaxId("07158236906")).toBe(false);
  });

  it("validates social security numbers", () => {
    expect(isValidSocialSecurityNumber("65 170839 J 003")).toBe(true);
    expect(isValidSocialSecurityNumber("65 170839 J 004")).toBe(false);
    expect(isValidSocialSecurityNumber("65 171339 J 003")).toBe(false);
  });
});

describe("findLineMatches", () => {
  it("maps a match that spans several words back to word indices", () => {
    const spans = findLineMatches(line("IBAN: DE89 3704 0044 0532 0130 00 Bank").words, /DE\d{2}(?: ?\d{4}){4} ?\d{2}/g);
    expect(spans).toEqual([{ first: 1, last: 6, text: "DE89 3704 0044 0532 0130 00" }]);
  });
});

describe("detectSensitiveData", () => {
  it("finds banking data", () => {
    expect(kindsOf("IBAN DE89 3704 0044 0532 0130 00 BIC COBADEFFXXX")).toEqual(["iban", "bic"]);
  });

  it("finds tax and social security numbers only when the checksum holds", () => {
    expect(kindsOf("Steuer-ID 47 158 236 906")).toEqual(["taxId"]);
    expect(kindsOf("Steuer-ID 47 158 236 905")).toEqual([]);
    expect(kindsOf("SV-Nummer 65 170839 J 003")).toEqual(["socialSecurity"]);
  });

  it("finds contact details", () => {
    expect(kindsOf("Mail max.mustermann@example.com Tel. +49 30 1234 5678")).toEqual(["email", "phone"]);
  });

  it("needs context before flagging document numbers", () => {
    expect(kindsOf("Passnummer U12345678")).toEqual(["documentNumber"]);
    expect(kindsOf("Rechnung U12345678")).toEqual([]);
  });

  it("blacks out only the value next to a label", () => {
    const [religion] = detectSensitiveData([line("Konfession: ev")], SIZE, makeId);
    expect(religion?.kind).toBe("religion");
    expect(religion?.text).toBe("ev");
    expect(religion?.x).toBeGreaterThan(0.1);
    expect(kindsOf("Personalnummer 004711")).toEqual(["personnelNumber"]);
    expect(kindsOf("Konfession")).toEqual([]);
  });

  it("reads the label from the line above", () => {
    const lines = [line("Dokumentnummer", 100), line("YOA12B3C4", 140)];
    expect(detectSensitiveData(lines, SIZE, makeId).map((s) => s.kind)).toEqual(["documentNumber"]);
    expect(kindsOf("CAN 123456")).toEqual(["documentNumber"]);
  });

  it("ignores amounts and dates", () => {
    expect(kindsOf("Netto 2.612,34 EUR am 01.10.2026")).toEqual([]);
  });

  it("treats machine readable zone lines as a whole", () => {
    expect(isMrzLine("IAD<<T22000129<<<<<<<<<<<<<<<")).toBe(true);
    expect(isMrzLine("Musterstraße 1 10115 Berlin")).toBe(false);
    expect(kindsOf("MUSTERMANN<<MAX<<<<<<<<<<<<<<<<")).toEqual(["mrz"]);
  });

  it("returns normalized rectangles inside the page", () => {
    for (const suggestion of detectSensitiveData([line("IBAN DE89 3704 0044 0532 0130 00")], SIZE, makeId)) {
      expect(suggestion.x).toBeGreaterThanOrEqual(0);
      expect(suggestion.x + suggestion.width).toBeLessThanOrEqual(1);
    }
  });
});
