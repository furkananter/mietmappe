const SHAPE = /^(\d{2})(\d{2})(\d{2})(\d{2})([A-Z])(\d{2})(\d)$/;
const WEIGHTS = [2, 1, 2, 5, 7, 1, 2, 1, 2, 1, 2, 1];

const crossSum = (value: number): number => String(value).split("").reduce((sum, digit) => sum + Number(digit), 0);

export function socialSecurityCheckDigit(withoutCheck: string): number {
  const letter = withoutCheck.charAt(8);
  const letterDigits = String(letter.charCodeAt(0) - 64).padStart(2, "0");
  const digits = `${withoutCheck.slice(0, 8)}${letterDigits}${withoutCheck.slice(9, 11)}`;
  const total = WEIGHTS.reduce((sum, weight, index) => sum + crossSum(Number(digits[index]) * weight), 0);
  return total % 10;
}

export default function isValidSocialSecurityNumber(raw: string): boolean {
  const compact = raw.replace(/\s+/g, "").toUpperCase();
  const match = SHAPE.exec(compact);
  if (!match) return false;
  const day = Number(match[2]) % 50;
  const month = Number(match[3]);
  if (day < 1 || day > 31 || month < 1 || month > 12) return false;
  return socialSecurityCheckDigit(compact.slice(0, 11)) === Number(match[7]);
}
