import type { NormalizedRect } from "../types";

const COVERAGE_THRESHOLD = 0.8;

function intersectionArea(a: NormalizedRect, b: NormalizedRect): number {
  const width = Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x);
  const height = Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y);
  return width > 0 && height > 0 ? width * height : 0;
}

export default function isCoveredByRedactions(rect: NormalizedRect, redactions: NormalizedRect[]): boolean {
  const area = rect.width * rect.height;
  if (area === 0) return true;
  const covered = redactions.reduce((sum, redaction) => sum + intersectionArea(rect, redaction), 0);
  return covered / area >= COVERAGE_THRESHOLD;
}
