import type { OcrWord } from "../ocr/ocrTypes";

export interface WordSpan {
  first: number;
  last: number;
  text: string;
}

export function joinWords(words: OcrWord[]): { text: string; starts: number[] } {
  const starts: number[] = [];
  let text = "";
  words.forEach((word, index) => {
    if (index > 0) text += " ";
    starts.push(text.length);
    text += word.text;
  });
  return { text, starts };
}

export default function findLineMatches(words: OcrWord[], pattern: RegExp): WordSpan[] {
  const { text, starts } = joinWords(words);
  const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
  const spans: WordSpan[] = [];

  for (const match of text.matchAll(new RegExp(pattern.source, flags))) {
    const start = match.index;
    const end = start + match[0].length;
    let first = -1;
    let last = -1;
    words.forEach((word, index) => {
      const wordStart = starts[index] ?? 0;
      const wordEnd = wordStart + word.text.length;
      if (wordStart < end && wordEnd > start) {
        if (first < 0) first = index;
        last = index;
      }
    });
    if (first >= 0) spans.push({ first, last, text: match[0] });
  }
  return spans;
}
