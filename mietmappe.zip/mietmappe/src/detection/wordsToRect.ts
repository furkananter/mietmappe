import type { OcrWord, PageSize } from "../ocr/ocrTypes";
import type { NormalizedRect } from "../types";

const PADDING = 0.004;

const clamp01 = (value: number): number => Math.min(1, Math.max(0, value));

export default function wordsToRect(words: OcrWord[], size: PageSize): NormalizedRect {
  const x0 = Math.min(...words.map((word) => word.bbox.x0));
  const y0 = Math.min(...words.map((word) => word.bbox.y0));
  const x1 = Math.max(...words.map((word) => word.bbox.x1));
  const y1 = Math.max(...words.map((word) => word.bbox.y1));

  const left = clamp01(x0 / size.width - PADDING);
  const top = clamp01(y0 / size.height - PADDING);
  const right = clamp01(x1 / size.width + PADDING);
  const bottom = clamp01(y1 / size.height + PADDING);
  return { x: left, y: top, width: right - left, height: bottom - top };
}
