import { describe, expect, it } from "vitest";

import { formatMessage } from "../createTranslator";
import { de } from "../messages/de";
import { en } from "../messages/en";

const placeholders = (text: string) => [...text.matchAll(/\{(\w+)\}/g)].map((match) => match[1]).sort();

describe("messages", () => {
  it("has the same keys in English and German", () => {
    expect(Object.keys(de).sort()).toEqual(Object.keys(en).sort());
  });

  it("uses the same placeholders in both languages", () => {
    for (const key of Object.keys(en) as (keyof typeof en)[]) {
      expect(placeholders(de[key]), key).toEqual(placeholders(en[key]));
    }
  });

  it("contains no em dashes", () => {
    for (const text of [...Object.values(en), ...Object.values(de)]) expect(text).not.toContain("—");
  });

  it("fills placeholders and keeps unknown ones", () => {
    expect(formatMessage("Page {current} of {total}", { current: 2, total: 5 })).toBe("Page 2 of 5");
    expect(formatMessage("Hi {name}")).toBe("Hi {name}");
  });
});
