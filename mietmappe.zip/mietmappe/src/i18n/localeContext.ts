import { createContext } from "react";

import type { Locale } from "../types";
import type { Translate } from "./createTranslator";

export interface LocaleValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: Translate;
}

const localeContext = createContext<LocaleValue | null>(null);

export default localeContext;
