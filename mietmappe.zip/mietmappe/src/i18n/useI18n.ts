import { use } from "react";

import localeContext, { type LocaleValue } from "./localeContext";

export default function useI18n(): LocaleValue {
  const value = use(localeContext);
  if (!value) throw new Error("useI18n must be used inside LocaleProvider");
  return value;
}
