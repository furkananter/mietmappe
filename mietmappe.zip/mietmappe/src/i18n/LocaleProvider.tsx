import { type ReactNode, useCallback, useMemo, useState } from "react";

import type { Locale } from "../types";
import createTranslator from "./createTranslator";
import localeContext from "./localeContext";
import { writeLocale } from "./localeStorage";

interface LocaleProviderProps {
  initialLocale: Locale;
  children: ReactNode;
}

export default function LocaleProvider({ initialLocale, children }: LocaleProviderProps) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale);

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    document.documentElement.lang = next;
    writeLocale(next);
  }, []);

  const value = useMemo(() => ({ locale, setLocale, t: createTranslator(locale) }), [locale, setLocale]);

  return <localeContext.Provider value={value}>{children}</localeContext.Provider>;
}
