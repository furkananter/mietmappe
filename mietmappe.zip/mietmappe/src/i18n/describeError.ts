import { type AppError, ExportError, FileProcessingError, OcrError, StorageError } from "../lib/errors";
import type { Translate } from "./createTranslator";

export default function describeError(error: AppError, t: Translate): string {
  if (error instanceof FileProcessingError) return t(`error.file.${error.reason}`, { name: error.fileName });
  if (error instanceof ExportError) return t(`error.export.${error.reason}`);
  if (error instanceof OcrError) return t(`error.ocr.${error.reason}`);
  if (error instanceof StorageError) return t("error.storage");
  return t("error.unexpected");
}
