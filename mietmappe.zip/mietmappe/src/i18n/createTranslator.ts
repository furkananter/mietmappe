import type { Locale } from "../types";
import { de } from "./messages/de";
import { en, type MessageKey, type Messages } from "./messages/en";

export type MessageParams = Record<string, string | number>;
export type Translate = (key: MessageKey, params?: MessageParams) => string;

const DICTIONARIES: Record<Locale, Messages> = { en, de };

export function formatMessage(template: string, params: MessageParams = {}): string {
  return template.replace(/\{(\w+)\}/g, (placeholder, name: string) =>
    name in params ? String(params[name]) : placeholder,
  );
}

export default function createTranslator(locale: Locale): Translate {
  const dictionary = DICTIONARIES[locale];
  return (key, params) => formatMessage(dictionary[key], params);
}
