import type { Locale } from "../types";

const STORAGE_KEY = "mietmappe.locale";

const isLocale = (value: unknown): value is Locale => value === "en" || value === "de";

export function readInitialLocale(): Locale {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (isLocale(stored)) return stored;
  } catch {
    return "en";
  }
  return navigator.language.toLowerCase().startsWith("de") ? "de" : "en";
}

export function writeLocale(locale: Locale): void {
  try {
    localStorage.setItem(STORAGE_KEY, locale);
  } catch {
    return;
  }
}
