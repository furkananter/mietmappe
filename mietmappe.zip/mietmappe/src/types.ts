export interface Point {
  x: number;
  y: number;
}

export interface NormalizedRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Redaction extends NormalizedRect {
  id: string;
}

export type DocumentKind =
  | "payslip"
  | "residencePermit"
  | "idCard"
  | "bankStatement"
  | "employerLetter"
  | "schufa"
  | "other";

export interface DocumentPage {
  id: string;
  sourceName: string;
  pageNumber: number;
  imageUrl: string;
  width: number;
  height: number;
  kind: DocumentKind;
  redactions: Redaction[];
}

export type SensitiveKind =
  | "iban"
  | "bic"
  | "taxId"
  | "socialSecurity"
  | "mrz"
  | "documentNumber"
  | "email"
  | "phone"
  | "religion"
  | "personnelNumber"
  | "insuranceNumber";

export interface Suggestion extends NormalizedRect {
  id: string;
  kind: SensitiveKind;
  text: string;
}

export interface ApplicationLogEntry {
  id: string;
  sentAt: string;
  recipient: string;
  address: string;
  fileName: string;
  documents: string[];
}

export type MoveDirection = "up" | "down";

export type Locale = "en" | "de";
