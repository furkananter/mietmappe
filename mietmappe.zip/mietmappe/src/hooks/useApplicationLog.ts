import { useCallback, useState } from "react";

import { readLog, writeLog } from "../lib/applicationLogStorage";
import { type AppError, toAppError } from "../lib/errors";
import type { ApplicationLogEntry } from "../types";

export default function useApplicationLog() {
  const [entries, setEntries] = useState<ApplicationLogEntry[]>(readLog);
  const [storageError, setStorageError] = useState<AppError | null>(null);

  const persist = useCallback((next: ApplicationLogEntry[]) => {
    setEntries(next);
    try {
      writeLog(next);
      setStorageError(null);
    } catch (error) {
      setStorageError(toAppError(error));
    }
  }, []);

  const addEntry = useCallback(
    (entry: ApplicationLogEntry) => persist([entry, ...entries]),
    [entries, persist],
  );

  const removeEntry = useCallback(
    (entryId: string) => persist(entries.filter((entry) => entry.id !== entryId)),
    [entries, persist],
  );

  return { entries, storageError, addEntry, removeEntry };
}
