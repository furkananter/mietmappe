import { useCallback, useState } from "react";

import { commit, createHistory, redo, undo } from "../lib/history";

export default function useHistoryState<T>(initial: T) {
  const [history, setHistory] = useState(() => createHistory(initial));

  const update = useCallback((updater: (current: T) => T) => {
    setHistory((previous) => commit(previous, updater(previous.present)));
  }, []);

  const undoLast = useCallback(() => setHistory((previous) => undo(previous)), []);
  const redoLast = useCallback(() => setHistory((previous) => redo(previous)), []);

  return {
    present: history.present,
    update,
    undo: undoLast,
    redo: redoLast,
    canUndo: history.past.length > 0,
    canRedo: history.future.length > 0,
  };
}
