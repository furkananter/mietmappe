import { useCallback, useState } from "react";

import createId from "../lib/createId";
import { type AppError, toAppError } from "../lib/errors";
import filesToPages from "../lib/filesToPages";
import {
  addRedactions,
  adjacentPageId,
  movePage,
  removePageById,
  removeRedaction,
  setPageKind,
} from "../lib/pageListOperations";
import createSamplePages from "../samples/createSamplePages";
import type { DocumentKind, DocumentPage, MoveDirection, NormalizedRect } from "../types";
import useHistoryState from "./useHistoryState";

export default function useDocumentPages() {
  const history = useHistoryState<DocumentPage[]>([]);
  const { present: pages, update } = history;
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<AppError[]>([]);

  const appendPages = useCallback(
    (added: DocumentPage[]) => {
      update((current) => (added.length === 0 ? current : [...current, ...added]));
      const firstAdded = added[0];
      if (firstAdded) setSelectedId((current) => current ?? firstAdded.id);
    },
    [update],
  );

  const load = useCallback(
    async (source: () => Promise<{ pages: DocumentPage[]; errors: AppError[] }>) => {
      setIsLoading(true);
      try {
        const result = await source();
        appendPages(result.pages);
        setErrors(result.errors);
      } catch (error) {
        setErrors([toAppError(error)]);
      } finally {
        setIsLoading(false);
      }
    },
    [appendPages],
  );

  const addFiles = useCallback((files: File[]) => load(() => filesToPages(files)), [load]);

  const loadSamples = useCallback(
    () => load(async () => ({ pages: await createSamplePages(), errors: [] })),
    [load],
  );

  const removePage = useCallback(
    (pageId: string) => {
      update((current) => removePageById(current, pageId));
      setSelectedId((current) => (current === pageId ? null : current));
    },
    [update],
  );

  const move = useCallback(
    (pageId: string, direction: MoveDirection) => update((current) => movePage(current, pageId, direction)),
    [update],
  );

  const redact = useCallback(
    (pageId: string, rects: NormalizedRect[]) =>
      update((current) => addRedactions(current, pageId, rects.map((rect) => ({ ...rect, id: createId() })))),
    [update],
  );

  const unredact = useCallback(
    (pageId: string, redactionId: string) => update((current) => removeRedaction(current, pageId, redactionId)),
    [update],
  );

  const setKind = useCallback(
    (pageId: string, kind: DocumentKind) => update((current) => setPageKind(current, pageId, kind)),
    [update],
  );

  const selectAdjacent = useCallback(
    (delta: number) => setSelectedId(adjacentPageId(pages, selectedId, delta)),
    [pages, selectedId],
  );

  const selectedPage = pages.find((page) => page.id === selectedId) ?? null;

  return {
    pages,
    selectedPage,
    isLoading,
    errors,
    addFiles,
    loadSamples,
    removePage,
    move,
    redact,
    unredact,
    setKind,
    select: setSelectedId,
    selectAdjacent,
    undo: history.undo,
    redo: history.redo,
    canUndo: history.canUndo,
    canRedo: history.canRedo,
  };
}
