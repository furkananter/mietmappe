import { useCallback } from "react";

import matchShortcut, { type ShortcutAction } from "../lib/matchShortcut";

const TYPING_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT"]);

function isTypingTarget(target: EventTarget | null): boolean {
  return target instanceof HTMLElement && (TYPING_TAGS.has(target.tagName) || target.isContentEditable);
}

export default function useKeyboardShortcuts(handlers: Record<ShortcutAction, () => void>) {
  return useCallback(
    (node: HTMLElement | null) => {
      if (!node) return undefined;
      const owner = node.ownerDocument;
      const listener = (event: KeyboardEvent) => {
        const action = matchShortcut({
          key: event.key,
          metaKey: event.metaKey,
          ctrlKey: event.ctrlKey,
          shiftKey: event.shiftKey,
          isTyping: isTypingTarget(event.target),
        });
        if (!action) return;
        event.preventDefault();
        handlers[action]();
      };
      owner.addEventListener("keydown", listener);
      return () => owner.removeEventListener("keydown", listener);
    },
    [handlers],
  );
}
