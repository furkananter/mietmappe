import { useCallback, useState } from "react";

import buildFileName from "../lib/buildFileName";
import buildWatermarkText from "../lib/buildWatermarkText";
import createId from "../lib/createId";
import downloadBlob from "../lib/downloadBlob";
import { type AppError, toAppError } from "../lib/errors";
import exportApplicationPdf from "../lib/exportApplicationPdf";
import { uniqueSourceNames } from "../lib/pageListOperations";
import type { ApplicationLogEntry, DocumentPage } from "../types";

interface ExportInput {
  pages: DocumentPage[];
  address: string;
  recipient: string;
  onExported: (entry: ApplicationLogEntry) => void;
}

export default function useApplicationExport() {
  const [isExporting, setIsExporting] = useState(false);
  const [exportError, setExportError] = useState<AppError | null>(null);

  const runExport = useCallback(async ({ pages, address, recipient, onExported }: ExportInput) => {
    setIsExporting(true);
    setExportError(null);
    try {
      const now = new Date();
      const blob = await exportApplicationPdf(pages, buildWatermarkText(address, recipient, now));
      const fileName = buildFileName(address, now);
      downloadBlob(blob, fileName);
      onExported({
        id: createId(),
        sentAt: now.toISOString(),
        recipient: recipient.trim(),
        address: address.trim(),
        fileName,
        documents: uniqueSourceNames(pages),
      });
    } catch (error) {
      setExportError(toAppError(error));
    } finally {
      setIsExporting(false);
    }
  }, []);

  return { isExporting, exportError, runExport };
}
