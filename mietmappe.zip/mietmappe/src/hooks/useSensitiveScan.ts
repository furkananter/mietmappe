import { useCallback, useRef, useState } from "react";

import detectSensitiveData from "../detection/detectSensitiveData";
import isCoveredByRedactions from "../detection/isCoveredByRedactions";
import { type AppError, OcrError, toAppError } from "../lib/errors";
import createOcrEngine, { type OcrEngine } from "../ocr/createOcrEngine";
import type { DocumentPage, Suggestion } from "../types";

export type ScanStatus =
  | { phase: "idle" }
  | { phase: "loading" }
  | { phase: "scanning"; current: number; total: number; progress: number };

export default function useSensitiveScan() {
  const engineRef = useRef<Promise<OcrEngine> | null>(null);
  const [suggestions, setSuggestions] = useState<Record<string, Suggestion[]>>({});
  const [scanned, setScanned] = useState<Record<string, boolean>>({});
  const [status, setStatus] = useState<ScanStatus>({ phase: "idle" });
  const [error, setError] = useState<AppError | null>(null);

  const loadEngine = useCallback(() => {
    engineRef.current ??= createOcrEngine();
    return engineRef.current;
  }, []);

  const scan = useCallback(
    async (targets: DocumentPage[]) => {
      if (targets.length === 0) return;
      setError(null);
      setStatus({ phase: "loading" });
      try {
        const engine = await loadEngine();
        for (const [index, target] of targets.entries()) {
          const report = (progress: number) =>
            setStatus({ phase: "scanning", current: index + 1, total: targets.length, progress });
          report(0);
          const lines = await engine.recognize(target.imageUrl, report);
          const found = detectSensitiveData(lines, target).filter(
            (suggestion) => !isCoveredByRedactions(suggestion, target.redactions),
          );
          setSuggestions((current) => ({ ...current, [target.id]: found }));
          setScanned((current) => ({ ...current, [target.id]: true }));
        }
      } catch (caught) {
        const appError = toAppError(caught);
        if (appError instanceof OcrError && appError.reason === "load") engineRef.current = null;
        setError(appError);
      } finally {
        setStatus({ phase: "idle" });
      }
    },
    [loadEngine],
  );

  const dismiss = useCallback((pageId: string, suggestionIds: readonly string[] | "all") => {
    setSuggestions((current) => ({
      ...current,
      [pageId]: suggestionIds === "all" ? [] : (current[pageId] ?? []).filter((item) => !suggestionIds.includes(item.id)),
    }));
  }, []);

  return { suggestions, scanned, status, error, scan, dismiss };
}
