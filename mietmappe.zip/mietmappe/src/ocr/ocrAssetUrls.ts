export interface OcrAssetUrls {
  worker: string;
  core: string;
  lang: string;
}

export default function ocrAssetUrls(): OcrAssetUrls {
  const base = new URL(import.meta.env.BASE_URL, window.location.href);
  return {
    worker: new URL("ocr/worker.min.js", base).href,
    core: new URL("ocr/core", base).href,
    lang: new URL("ocr/lang", base).href,
  };
}
