import type { OcrBox, OcrLine } from "./ocrTypes";

interface RecognizedWord {
  text: string;
  bbox: OcrBox;
}

interface RecognizedBlock {
  paragraphs: { lines: { words: RecognizedWord[] }[] }[];
}

export default function extractLines(blocks: RecognizedBlock[] | null): OcrLine[] {
  if (!blocks) return [];
  return blocks.flatMap((block) =>
    block.paragraphs.flatMap((paragraph) =>
      paragraph.lines.map((line) => ({
        words: line.words
          .filter((word) => word.text.trim().length > 0)
          .map((word) => ({ text: word.text.trim(), bbox: word.bbox })),
      })),
    ),
  );
}
