import { OcrError } from "../lib/errors";
import extractLines from "./extractLines";
import ocrAssetUrls from "./ocrAssetUrls";
import type { OcrLine } from "./ocrTypes";

export type ProgressListener = (progress: number) => void;

export interface OcrEngine {
  recognize: (imageUrl: string, onProgress: ProgressListener) => Promise<OcrLine[]>;
  terminate: () => Promise<void>;
}

const LSTM_ONLY = 1;
const RECOGNIZING = "recognizing text";

export default async function createOcrEngine(): Promise<OcrEngine> {
  let listener: ProgressListener = () => undefined;

  try {
    const tesseract = (await import("tesseract.js")).default;
    const urls = ocrAssetUrls();
    const worker = await tesseract.createWorker("deu", LSTM_ONLY, {
      workerPath: urls.worker,
      corePath: urls.core,
      langPath: urls.lang,
      workerBlobURL: false,
      logger: (message) => {
        if (message.status === RECOGNIZING) listener(message.progress);
      },
    });

    return {
      recognize: async (imageUrl, onProgress) => {
        listener = onProgress;
        try {
          const result = await worker.recognize(imageUrl, {}, { blocks: true });
          return extractLines(result.data.blocks);
        } catch (error) {
          throw new OcrError("recognize", { cause: error });
        } finally {
          listener = () => undefined;
        }
      },
      terminate: async () => {
        await worker.terminate();
      },
    };
  } catch (error) {
    throw new OcrError("load", { cause: error });
  }
}
