export interface OcrBox {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export interface OcrWord {
  text: string;
  bbox: OcrBox;
}

export interface OcrLine {
  words: OcrWord[];
}

export interface PageSize {
  width: number;
  height: number;
}
