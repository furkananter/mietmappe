import { FolderLock, ShieldCheck } from "lucide-react";

import { REPOSITORY_URL } from "../config";
import useI18n from "../i18n/useI18n";
import GithubMark from "./GithubMark";
import LanguageToggle from "./LanguageToggle";
import ThemeToggle from "./ThemeToggle";
import { Badge } from "./ui/badge";
import { buttonVariants } from "./ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";

export default function AppHeader() {
  const { t } = useI18n();

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-3 border-b bg-card px-4">
      <div className="flex min-w-0 items-center gap-2.5">
        <span className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground" aria-hidden="true">
          <FolderLock className="size-4" strokeWidth={2.2} />
        </span>
        <span className="text-[15px] font-semibold tracking-tight">Mietmappe</span>
        <span className="hidden truncate text-[13px] text-muted-foreground xl:inline">
          <span className="mr-2.5 text-border">/</span>
          {t("app.tagline")}
        </span>
      </div>
      <div className="flex items-center gap-2.5">
        <Badge variant="success" className="hidden h-6 px-2.5 text-xs md:inline-flex">
          <ShieldCheck className="size-3.5" aria-hidden="true" />
          {t("app.privacy")}
        </Badge>
        <LanguageToggle />
        <ThemeToggle />
        <Tooltip>
          <TooltipTrigger asChild>
            <a
              className={buttonVariants({ variant: "ghost", size: "iconSm" })}
              href={REPOSITORY_URL}
              target="_blank"
              rel="noreferrer"
              aria-label={t("app.github")}
            >
              <GithubMark className="size-4" />
            </a>
          </TooltipTrigger>
          <TooltipContent>{t("app.github")}</TooltipContent>
        </Tooltip>
      </div>
    </header>
  );
}
