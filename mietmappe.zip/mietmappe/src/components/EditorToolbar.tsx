import { Redo2, ScanSearch, Undo2 } from "lucide-react";

import type { ScanStatus } from "../hooks/useSensitiveScan";
import useI18n from "../i18n/useI18n";
import IconButton from "./IconButton";
import ScanStatusIndicator from "./ScanStatusIndicator";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";

interface EditorToolbarProps {
  pageIndex: number;
  pageCount: number;
  canUndo: boolean;
  canRedo: boolean;
  status: ScanStatus;
  onUndo: () => void;
  onRedo: () => void;
  onScanPage: () => void;
  onScanAll: () => void;
}

export default function EditorToolbar(props: EditorToolbarProps) {
  const { t } = useI18n();
  const isBusy = props.status.phase !== "idle";

  return (
    <div className="sticky top-0 z-10 flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-card/90 px-2.5 py-2 backdrop-blur">
      <div className="flex items-center gap-1">
        <IconButton label={t("editor.undo")} disabled={!props.canUndo} onClick={props.onUndo}>
          <Undo2 className="size-4" aria-hidden="true" />
        </IconButton>
        <IconButton label={t("editor.redo")} disabled={!props.canRedo} onClick={props.onRedo}>
          <Redo2 className="size-4" aria-hidden="true" />
        </IconButton>
        <Separator orientation="vertical" className="mx-2 h-4" />
        <span className="font-mono text-xs text-muted-foreground">
          {t("editor.pageOf", { current: props.pageIndex + 1, total: props.pageCount })}
        </span>
      </div>
      {isBusy ? (
        <ScanStatusIndicator status={props.status} />
      ) : (
        <div className="flex items-center gap-2">
          {props.pageCount > 1 ? (
            <Button variant="outline" size="sm" onClick={props.onScanAll}>
              {t("editor.scanAll")}
            </Button>
          ) : null}
          <Button variant="finding" size="sm" onClick={props.onScanPage}>
            <ScanSearch className="size-4" aria-hidden="true" />
            {t("editor.scanPage")}
          </Button>
        </div>
      )}
    </div>
  );
}
