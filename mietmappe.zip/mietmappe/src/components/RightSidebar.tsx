import { FileDown, ListChecks, ScrollText, Stamp } from "lucide-react";

import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";
import type { ApplicationLogEntry, DocumentKind, DocumentPage } from "../types";
import ApplicationLog from "./ApplicationLog";
import ChecklistPanel from "./ChecklistPanel";
import ExportPanel from "./ExportPanel";
import WatermarkSettings from "./WatermarkSettings";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

interface RightSidebarProps {
  page: DocumentPage | null;
  pageCount: number;
  unreviewedCount: number;
  address: string;
  recipient: string;
  watermarkPreview: string;
  isExporting: boolean;
  exportError: AppError | null;
  logEntries: ApplicationLogEntry[];
  logStorageError: AppError | null;
  onKindChange: (pageId: string, kind: DocumentKind) => void;
  onAddressChange: (value: string) => void;
  onRecipientChange: (value: string) => void;
  onExport: () => void;
  onLogRemove: (entryId: string) => void;
  onLogExportCsv: () => void;
}

export default function RightSidebar(props: RightSidebarProps) {
  const { t } = useI18n();

  return (
    <Tabs defaultValue="checklist" className="p-4">
      <TabsList>
        <TabsTrigger value="checklist">
          <ListChecks aria-hidden="true" />
          <span className="max-w-full truncate">{t("checklist.title")}</span>
        </TabsTrigger>
        <TabsTrigger value="watermark">
          <Stamp aria-hidden="true" />
          <span className="max-w-full truncate">{t("watermark.title")}</span>
        </TabsTrigger>
        <TabsTrigger value="export">
          <FileDown aria-hidden="true" />
          <span className="max-w-full truncate">{t("export.title")}</span>
        </TabsTrigger>
        <TabsTrigger value="log">
          <ScrollText aria-hidden="true" />
          <span className="max-w-full truncate">{t("log.title")}</span>
        </TabsTrigger>
      </TabsList>
      <TabsContent value="checklist">
        <ChecklistPanel page={props.page} onKindChange={props.onKindChange} />
      </TabsContent>
      <TabsContent value="watermark">
        <WatermarkSettings
          address={props.address}
          recipient={props.recipient}
          previewText={props.watermarkPreview}
          onAddressChange={props.onAddressChange}
          onRecipientChange={props.onRecipientChange}
        />
      </TabsContent>
      <TabsContent value="export">
        <ExportPanel
          pageCount={props.pageCount}
          unreviewedCount={props.unreviewedCount}
          isExporting={props.isExporting}
          error={props.exportError}
          onExport={props.onExport}
        />
      </TabsContent>
      <TabsContent value="log">
        <ApplicationLog
          entries={props.logEntries}
          storageError={props.logStorageError}
          onRemove={props.onLogRemove}
          onExportCsv={props.onLogExportCsv}
        />
      </TabsContent>
    </Tabs>
  );
}
