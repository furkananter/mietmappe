import { useMemo } from "react";
import { Download, Trash2 } from "lucide-react";

import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";
import type { ApplicationLogEntry } from "../types";
import ErrorText from "./ErrorText";
import IconButton from "./IconButton";
import PanelHeader from "./PanelHeader";
import { Button } from "./ui/button";

interface ApplicationLogProps {
  entries: ApplicationLogEntry[];
  storageError: AppError | null;
  onRemove: (entryId: string) => void;
  onExportCsv: () => void;
}

export default function ApplicationLog({ entries, storageError, onRemove, onExportCsv }: ApplicationLogProps) {
  const { t, locale } = useI18n();
  const dateFormat = useMemo(
    () => new Intl.DateTimeFormat(locale === "de" ? "de-DE" : "en-GB", { dateStyle: "medium", timeStyle: "short" }),
    [locale],
  );

  return (
    <section className="flex flex-col gap-4">
      <PanelHeader title={t("log.title")}>
        <Button variant="outline" size="xs" disabled={entries.length === 0} onClick={onExportCsv}>
          <Download className="size-3" aria-hidden="true" />
          {t("log.csv")}
        </Button>
      </PanelHeader>
      {storageError ? <ErrorText error={storageError} /> : null}
      {entries.length === 0 ? (
        <p className="m-0 rounded-xl border border-dashed p-4 text-center text-[13px] text-muted-foreground">{t("log.empty")}</p>
      ) : null}
      <ul className="m-0 flex list-none flex-col gap-2 p-0">
        {entries.map((entry) => (
          <li key={entry.id} className="flex items-start gap-2 rounded-xl border bg-card p-3">
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <strong className="text-[13px] font-medium">{entry.address || t("log.noAddress")}</strong>
              <span className="text-xs text-muted-foreground">
                {entry.recipient || t("log.noRecipient")} · {dateFormat.format(new Date(entry.sentAt))}
              </span>
              <span className="font-mono text-[11px] break-words text-muted-foreground">{entry.documents.join(", ")}</span>
            </div>
            <IconButton size="iconXs" variant="destructiveGhost" label={t("log.delete")} onClick={() => onRemove(entry.id)}>
              <Trash2 className="size-3.5" aria-hidden="true" />
            </IconButton>
          </li>
        ))}
      </ul>
    </section>
  );
}
