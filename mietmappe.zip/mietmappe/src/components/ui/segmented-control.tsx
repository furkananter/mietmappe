import type { ReactNode } from "react";

import cn from "../../lib/cn";

interface SegmentedOption<T extends string> {
  value: T;
  label: ReactNode;
  ariaLabel?: string;
}

interface SegmentedControlProps<T extends string> {
  options: readonly SegmentedOption<T>[];
  value: T;
  ariaLabel: string;
  onChange: (value: T) => void;
}

export function SegmentedControl<T extends string>({ options, value, ariaLabel, onChange }: SegmentedControlProps<T>) {
  return (
    <div role="group" aria-label={ariaLabel} className="inline-flex items-center gap-0.5 rounded-lg border bg-muted p-0.5">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          aria-pressed={option.value === value}
          aria-label={option.ariaLabel}
          title={option.ariaLabel}
          onClick={() => onChange(option.value)}
          className={cn(
            "inline-flex h-6 min-w-7 items-center justify-center rounded-md px-2 font-mono text-xs text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring",
            option.value === value && "bg-card text-foreground outline outline-1 outline-border",
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
