import { motion } from "motion/react";

interface BlurRevealProps {
  text: string;
  className?: string;
}

const STAGGER_SECONDS = 0.06;

export function BlurReveal({ text, className }: BlurRevealProps) {
  return (
    <h1 aria-label={text} className={className}>
      {text.split(" ").map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          aria-hidden="true"
          className="inline-block whitespace-pre"
          initial={{ opacity: 0, filter: "blur(10px)", y: 8 }}
          animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
          transition={{ duration: 0.6, delay: index * STAGGER_SECONDS, ease: "easeOut" }}
        >
          {word}{" "}
        </motion.span>
      ))}
    </h1>
  );
}
