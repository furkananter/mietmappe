import * as TabsPrimitive from "@radix-ui/react-tabs";
import type { ComponentProps } from "react";

import cn from "../../lib/cn";

export const Tabs = TabsPrimitive.Root;

export function TabsList({ className, ...props }: ComponentProps<typeof TabsPrimitive.List>) {
  return <TabsPrimitive.List className={cn("grid w-full grid-cols-4 gap-1 rounded-lg bg-muted p-1", className)} {...props} />;
}

export function TabsTrigger({ className, ...props }: ComponentProps<typeof TabsPrimitive.Trigger>) {
  return (
    <TabsPrimitive.Trigger
      className={cn(
        "flex min-w-0 flex-col items-center gap-1 rounded-md px-0 py-1.5 text-[10.5px] font-medium text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:outline data-[state=active]:outline-1 data-[state=active]:outline-border [&_svg]:size-4",
        className,
      )}
      {...props}
    />
  );
}

/** Content stays mounted so form state survives tab switches. */
export function TabsContent({ className, ...props }: ComponentProps<typeof TabsPrimitive.Content>) {
  return (
    <TabsPrimitive.Content
      forceMount
      className={cn("mt-4 outline-none data-[state=inactive]:hidden", className)}
      {...props}
    />
  );
}
