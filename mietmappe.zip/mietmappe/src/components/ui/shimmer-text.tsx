import { motion } from "motion/react";
import type { ReactNode } from "react";

import cn from "../../lib/cn";

interface ShimmerTextProps {
  className?: string;
  children: ReactNode;
}

export function ShimmerText({ className, children }: ShimmerTextProps) {
  return (
    <motion.span
      className={cn(
        "inline-block bg-size-[250%_100%] bg-clip-text text-transparent [background-image:linear-gradient(110deg,var(--finding)_35%,var(--foreground)_50%,var(--finding)_65%)]",
        className,
      )}
      initial={{ backgroundPositionX: "100%" }}
      animate={{ backgroundPositionX: "-100%" }}
      transition={{ duration: 2.2, ease: "linear", repeat: Infinity }}
    >
      {children}
    </motion.span>
  );
}
