import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { motion } from "motion/react";
import type { ReactNode } from "react";

import cn from "../../lib/cn";

interface AnimatedCheckboxProps {
  id: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  children: ReactNode;
}

const SPRING = { type: "spring", stiffness: 520, damping: 26 } as const;

export function AnimatedCheckbox({ id, checked, onCheckedChange, children }: AnimatedCheckboxProps) {
  return (
    <div className="flex items-start gap-2.5">
      <CheckboxPrimitive.Root
        id={id}
        checked={checked}
        onCheckedChange={(value) => onCheckedChange(value === true)}
        className="mt-0.5 size-4 shrink-0 rounded-[5px] outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
      >
        <motion.span
          initial={false}
          animate={{ scale: checked ? [1, 0.82, 1] : 1 }}
          transition={SPRING}
          className={cn(
            "flex size-4 items-center justify-center rounded-[5px] border transition-colors",
            checked ? "border-primary bg-primary text-primary-foreground" : "border-input bg-card",
          )}
        >
          <svg viewBox="0 0 16 16" className="size-3" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <motion.path
              d="M3.5 8.5l3 3 6-7"
              initial={false}
              animate={{ pathLength: checked ? 1 : 0, opacity: checked ? 1 : 0 }}
              transition={SPRING}
            />
          </svg>
        </motion.span>
      </CheckboxPrimitive.Root>
      <label
        htmlFor={id}
        className={cn(
          "cursor-pointer text-sm leading-5 line-through decoration-transparent decoration-1 transition-colors duration-300",
          checked ? "text-muted-foreground decoration-muted-foreground" : "text-foreground",
        )}
      >
        {children}
      </label>
    </div>
  );
}
