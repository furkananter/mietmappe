import { cva, type VariantProps } from "class-variance-authority";
import type { ComponentProps } from "react";

import cn from "../../lib/cn";

const badgeVariants = cva(
  "inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2 py-0.5 text-[11px] font-medium leading-4",
  {
    variants: {
      variant: {
        default: "border-transparent bg-muted text-foreground",
        outline: "border-border text-muted-foreground",
        success: "border-transparent bg-primary-soft text-primary",
        finding: "border-finding-border bg-finding-soft text-finding",
        ink: "border-transparent bg-foreground text-background",
        warning: "border-transparent bg-warning-soft text-warning",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

interface BadgeProps extends ComponentProps<"span">, VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
