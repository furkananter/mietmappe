import { type PointerEvent, useState } from "react";

import useI18n from "../i18n/useI18n";
import rectFromPoints from "../lib/rectFromPoints";
import type { DocumentPage, NormalizedRect, Point, Suggestion } from "../types";

interface RedactionEditorProps {
  page: DocumentPage;
  suggestions: Suggestion[];
  onAdd: (rect: NormalizedRect) => void;
  onRemove: (redactionId: string) => void;
  onAccept: (suggestion: Suggestion) => void;
}

const MIN_SIZE = 0.005;

function toPercentStyle(rect: NormalizedRect) {
  return {
    left: `${rect.x * 100}%`,
    top: `${rect.y * 100}%`,
    width: `${rect.width * 100}%`,
    height: `${rect.height * 100}%`,
  };
}

function relativePoint(event: PointerEvent<HTMLDivElement>): Point {
  const bounds = event.currentTarget.getBoundingClientRect();
  return { x: (event.clientX - bounds.left) / bounds.width, y: (event.clientY - bounds.top) / bounds.height };
}

const stopDrawing = (event: PointerEvent<HTMLButtonElement>) => event.stopPropagation();

export default function RedactionEditor({ page, suggestions, onAdd, onRemove, onAccept }: RedactionEditorProps) {
  const { t } = useI18n();
  const [start, setStart] = useState<Point | null>(null);
  const [draft, setDraft] = useState<NormalizedRect | null>(null);

  const handlePointerDown = (event: PointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = relativePoint(event);
    setStart(point);
    setDraft(rectFromPoints(point, point));
  };

  const handlePointerMove = (event: PointerEvent<HTMLDivElement>) => {
    if (start) setDraft(rectFromPoints(start, relativePoint(event)));
  };

  const handlePointerUp = () => {
    if (draft && draft.width > MIN_SIZE && draft.height > MIN_SIZE) onAdd(draft);
    setStart(null);
    setDraft(null);
  };

  return (
    <div className="flex flex-col gap-2.5">
      <p className="text-center text-xs text-muted-foreground">{t("editor.hint")}</p>
      <div className="flex justify-center">
        <div
          className="relative w-full max-w-[860px] cursor-crosshair touch-none select-none rounded-sm border bg-white"
          style={{ aspectRatio: `${page.width} / ${page.height}` }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
        >
          <img
            className="pointer-events-none block size-full"
            src={page.imageUrl}
            alt={`${page.sourceName}, ${t("docs.page", { number: page.pageNumber })}`}
            draggable={false}
          />
          {page.redactions.map((rect) => (
            <button
              key={rect.id}
              type="button"
              className="absolute cursor-pointer border-0 bg-black p-0 hover:outline-2 hover:outline-offset-1 hover:outline-destructive"
              style={toPercentStyle(rect)}
              aria-label={t("docs.remove")}
              onPointerDown={stopDrawing}
              onClick={() => onRemove(rect.id)}
            />
          ))}
          {suggestions.map((suggestion) => {
            const label = t(`sensitive.${suggestion.kind}`);
            return (
              <button
                key={suggestion.id}
                type="button"
                className="group absolute cursor-pointer rounded-xs border-2 border-dashed border-finding bg-finding/15 p-0 transition-colors hover:bg-finding/30"
                style={toPercentStyle(suggestion)}
                title={t("editor.acceptOne", { label })}
                aria-label={t("editor.acceptOne", { label })}
                onPointerDown={stopDrawing}
                onClick={() => onAccept(suggestion)}
              >
                <span className="pointer-events-none absolute bottom-full -left-0.5 whitespace-nowrap rounded-t-xs bg-finding px-1.5 font-mono text-[10px] leading-[15px] text-background">
                  {label}
                </span>
              </button>
            );
          })}
          {draft ? (
            <div className="pointer-events-none absolute bg-black/55" style={toPercentStyle(draft)} />
          ) : null}
        </div>
      </div>
    </div>
  );
}
