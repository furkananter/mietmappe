import { Keyboard } from "lucide-react";
import type { ReactNode } from "react";

import useI18n from "../i18n/useI18n";
import { Kbd } from "./ui/kbd";

const IS_MAC = typeof navigator !== "undefined" && /mac|iphone|ipad/i.test(navigator.userAgent);
const MOD = IS_MAC ? "⌘" : "Ctrl";

function ShortcutRow({ keys, children }: { keys: readonly string[]; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-xs text-muted-foreground">{children}</dt>
      <dd className="m-0 flex items-center gap-1">
        {keys.map((key) => (
          <Kbd key={key}>{key}</Kbd>
        ))}
      </dd>
    </div>
  );
}

export default function ShortcutsHint() {
  const { t } = useI18n();

  return (
    <section className="flex flex-col gap-2.5">
      <h3 className="flex items-center gap-1.5 text-xs font-medium">
        <Keyboard className="size-3.5 text-muted-foreground" aria-hidden="true" />
        {t("shortcuts.title")}
      </h3>
      <dl className="m-0 flex flex-col gap-2">
        <ShortcutRow keys={[MOD, "Z"]}>{t("shortcuts.undo")}</ShortcutRow>
        <ShortcutRow keys={[MOD, "Shift", "Z"]}>{t("shortcuts.redo")}</ShortcutRow>
        <ShortcutRow keys={["↑", "↓"]}>{t("shortcuts.navigate")}</ShortcutRow>
      </dl>
    </section>
  );
}
