import { Sparkles } from "lucide-react";

import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";
import type { DocumentPage, MoveDirection, Suggestion } from "../types";
import ErrorText from "./ErrorText";
import FileDropzone from "./FileDropzone";
import PageList from "./PageList";
import PanelHeader from "./PanelHeader";
import ShortcutsHint from "./ShortcutsHint";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";

interface DocumentsPanelProps {
  pages: DocumentPage[];
  selectedId: string | null;
  suggestions: Record<string, Suggestion[]>;
  isLoading: boolean;
  errors: AppError[];
  onFiles: (files: File[]) => void;
  onLoadSamples: () => void;
  onSelect: (pageId: string) => void;
  onMove: (pageId: string, direction: MoveDirection) => void;
  onRemove: (pageId: string) => void;
}

export default function DocumentsPanel(props: DocumentsPanelProps) {
  const { t } = useI18n();

  return (
    <div className="flex min-h-full flex-col gap-4 p-4">
      <PanelHeader title={t("docs.title")}>
        <Badge variant="default" className="font-mono">
          {props.pages.length}
        </Badge>
      </PanelHeader>
      <FileDropzone isLoading={props.isLoading} onFiles={props.onFiles} />
      <Button variant="ghost" size="sm" className="-mt-2 justify-start text-primary hover:text-primary" disabled={props.isLoading} onClick={props.onLoadSamples}>
        <Sparkles className="size-3.5" aria-hidden="true" />
        {t("docs.loadSamples")}
      </Button>
      {props.errors.map((error, index) => (
        <ErrorText key={`${error.message}-${index}`} error={error} />
      ))}
      <PageList
        pages={props.pages}
        selectedId={props.selectedId}
        suggestions={props.suggestions}
        onSelect={props.onSelect}
        onMove={props.onMove}
        onRemove={props.onRemove}
      />
      <div className="mt-auto flex flex-col gap-4 pt-2">
        <Separator />
        <ShortcutsHint />
      </div>
    </div>
  );
}
