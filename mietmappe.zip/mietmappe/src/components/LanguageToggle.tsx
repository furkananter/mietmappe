import useI18n from "../i18n/useI18n";
import type { Locale } from "../types";
import { SegmentedControl } from "./ui/segmented-control";

const OPTIONS: readonly { value: Locale; label: string }[] = [
  { value: "en", label: "EN" },
  { value: "de", label: "DE" },
];

export default function LanguageToggle() {
  const { locale, setLocale, t } = useI18n();

  return <SegmentedControl options={OPTIONS} value={locale} ariaLabel={t("app.language")} onChange={setLocale} />;
}
