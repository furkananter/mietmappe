import type { ScanStatus } from "../hooks/useSensitiveScan";
import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";
import type { DocumentPage, NormalizedRect, Suggestion } from "../types";
import EditorToolbar from "./EditorToolbar";
import EmptyState from "./EmptyState";
import ErrorText from "./ErrorText";
import RedactionEditor from "./RedactionEditor";
import SuggestionBar from "./SuggestionBar";

interface EditorStageProps {
  pages: DocumentPage[];
  page: DocumentPage | null;
  isLoading: boolean;
  suggestions: Suggestion[];
  wasScanned: boolean;
  scanStatus: ScanStatus;
  scanError: AppError | null;
  canUndo: boolean;
  canRedo: boolean;
  onFiles: (files: File[]) => void;
  onLoadSamples: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onScan: (targets: DocumentPage[]) => void;
  onRedact: (rects: NormalizedRect[]) => void;
  onUnredact: (redactionId: string) => void;
  onAccept: (items: Suggestion[]) => void;
  onDismissAll: () => void;
}

export default function EditorStage(props: EditorStageProps) {
  const { t } = useI18n();
  const { page, pages } = props;

  if (pages.length === 0) {
    return <EmptyState isLoading={props.isLoading} onFiles={props.onFiles} onLoadSamples={props.onLoadSamples} />;
  }
  if (!page) return <p className="px-6 py-16 text-center text-muted-foreground">{t("empty.selectPage")}</p>;

  return (
    <div className="mx-auto flex w-full max-w-[920px] flex-col gap-3 px-3 pt-3 pb-10 sm:px-6 sm:pt-4">
      <EditorToolbar
        pageIndex={pages.indexOf(page)}
        pageCount={pages.length}
        canUndo={props.canUndo}
        canRedo={props.canRedo}
        status={props.scanStatus}
        onUndo={props.onUndo}
        onRedo={props.onRedo}
        onScanPage={() => props.onScan([page])}
        onScanAll={() => props.onScan(pages)}
      />
      {props.scanError ? <ErrorText error={props.scanError} /> : null}
      <SuggestionBar
        suggestions={props.suggestions}
        wasScanned={props.wasScanned}
        onAcceptAll={() => props.onAccept(props.suggestions)}
        onDismissAll={props.onDismissAll}
      />
      <RedactionEditor
        page={page}
        suggestions={props.suggestions}
        onAdd={(rect) => props.onRedact([rect])}
        onRemove={props.onUnredact}
        onAccept={(suggestion) => props.onAccept([suggestion])}
      />
    </div>
  );
}
