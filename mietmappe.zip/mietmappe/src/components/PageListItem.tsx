import { ArrowDown, ArrowUp, ScanSearch, Trash2 } from "lucide-react";

import useI18n from "../i18n/useI18n";
import cn from "../lib/cn";
import type { DocumentPage, MoveDirection } from "../types";
import IconButton from "./IconButton";
import { Badge } from "./ui/badge";

interface PageListItemProps {
  page: DocumentPage;
  isSelected: boolean;
  isFirst: boolean;
  isLast: boolean;
  pendingSuggestions: number;
  onSelect: () => void;
  onMove: (direction: MoveDirection) => void;
  onRemove: () => void;
}

export default function PageListItem({
  page,
  isSelected,
  isFirst,
  isLast,
  pendingSuggestions,
  onSelect,
  onMove,
  onRemove,
}: PageListItemProps) {
  const { t } = useI18n();
  const label = `${page.sourceName}, ${t("docs.page", { number: page.pageNumber })}`;

  return (
    <li
      className={cn(
        "flex items-stretch rounded-xl border bg-card transition-colors",
        isSelected ? "border-primary bg-primary-soft" : "hover:bg-muted/60",
      )}
    >
      <button
        type="button"
        className="flex min-w-0 flex-1 items-start gap-3 rounded-xl p-2.5 text-left outline-none focus-visible:outline-2 focus-visible:outline-ring"
        aria-current={isSelected}
        onClick={onSelect}
      >
        <span className="w-11 shrink-0 overflow-hidden rounded-md border bg-white">
          <img className="block w-full" src={page.imageUrl} alt="" />
        </span>
        <span className="flex min-w-0 flex-col gap-0.5">
          <span className="truncate text-[13px] font-medium" title={page.sourceName}>
            {page.sourceName}
          </span>
          <span className="text-xs text-muted-foreground">{t(`kind.${page.kind}`)}</span>
          <span className="mt-1 flex flex-wrap items-center gap-1.5 font-mono text-[11px] text-muted-foreground">
            <span>{t("docs.page", { number: page.pageNumber })}</span>
            {page.redactions.length > 0 ? (
              <Badge variant="ink">{t("docs.redacted", { count: page.redactions.length })}</Badge>
            ) : null}
            {pendingSuggestions > 0 ? (
              <Badge variant="finding">
                <ScanSearch className="size-3" aria-hidden="true" />
                {pendingSuggestions}
              </Badge>
            ) : null}
          </span>
        </span>
      </button>
      <div className="flex flex-col justify-center border-l p-1">
        <IconButton size="iconXs" disabled={isFirst} label={`${t("docs.moveUp")}: ${label}`} onClick={() => onMove("up")}>
          <ArrowUp className="size-3.5" aria-hidden="true" />
        </IconButton>
        <IconButton size="iconXs" disabled={isLast} label={`${t("docs.moveDown")}: ${label}`} onClick={() => onMove("down")}>
          <ArrowDown className="size-3.5" aria-hidden="true" />
        </IconButton>
        <IconButton size="iconXs" variant="destructiveGhost" label={`${t("docs.remove")}: ${label}`} onClick={onRemove}>
          <Trash2 className="size-3.5" aria-hidden="true" />
        </IconButton>
      </div>
    </li>
  );
}
