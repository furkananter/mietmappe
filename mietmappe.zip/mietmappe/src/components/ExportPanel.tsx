import { FileDown, ShieldCheck, TriangleAlert } from "lucide-react";

import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";
import ErrorText from "./ErrorText";
import PanelHeader from "./PanelHeader";
import { Button } from "./ui/button";
import { Spinner } from "./ui/spinner";

interface ExportPanelProps {
  pageCount: number;
  unreviewedCount: number;
  isExporting: boolean;
  error: AppError | null;
  onExport: () => void;
}

export default function ExportPanel({ pageCount, unreviewedCount, isExporting, error, onExport }: ExportPanelProps) {
  const { t } = useI18n();
  const buttonLabel = pageCount === 1 ? t("export.button.one") : t("export.button.other", { count: pageCount });
  const warning =
    unreviewedCount === 1 ? t("export.unreviewed.one") : t("export.unreviewed.other", { count: unreviewedCount });

  return (
    <section className="flex flex-col gap-4">
      <PanelHeader title={t("export.title")} />
      <p className="m-0 flex items-start gap-2.5 rounded-xl border bg-muted/60 p-3 text-[13px] leading-5 text-muted-foreground">
        <ShieldCheck className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
        {t("export.note")}
      </p>
      {unreviewedCount > 0 ? (
        <p className="m-0 flex items-start gap-2 rounded-xl border border-warning/30 bg-warning-soft p-3 text-xs text-warning">
          <TriangleAlert className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
          <span>{warning}</span>
        </p>
      ) : null}
      <Button size="lg" className="w-full" disabled={pageCount === 0 || isExporting} onClick={onExport}>
        {isExporting ? <Spinner /> : <FileDown className="size-4" aria-hidden="true" />}
        {isExporting ? t("export.busy") : buttonLabel}
      </Button>
      {error ? <ErrorText error={error} /> : null}
    </section>
  );
}
