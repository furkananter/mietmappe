import type { ChangeEvent, ReactNode } from "react";

export const ACCEPTED_FILES = "application/pdf,image/png,image/jpeg,image/webp";

interface FilePickerButtonProps {
  className: string;
  disabled?: boolean;
  onFiles: (files: File[]) => void;
  children: ReactNode;
}

export default function FilePickerButton({ className, disabled = false, onFiles, children }: FilePickerButtonProps) {
  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    onFiles(Array.from(event.target.files ?? []));
    event.target.value = "";
  };

  return (
    <label className={className} aria-disabled={disabled}>
      <input type="file" accept={ACCEPTED_FILES} multiple hidden disabled={disabled} onChange={handleChange} />
      {children}
    </label>
  );
}
