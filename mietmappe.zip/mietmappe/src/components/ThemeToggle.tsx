import { Monitor, Moon, Sun } from "lucide-react";
import { type ReactNode, useSyncExternalStore } from "react";

import useI18n from "../i18n/useI18n";
import themeStore, { type Theme } from "../theme/themeStore";
import { SegmentedControl } from "./ui/segmented-control";

export default function ThemeToggle() {
  const { t } = useI18n();
  const theme = useSyncExternalStore(themeStore.subscribe, themeStore.getSnapshot);
  const options: readonly { value: Theme; label: ReactNode; ariaLabel: string }[] = [
    { value: "light", label: <Sun className="size-3.5" aria-hidden="true" />, ariaLabel: t("theme.light") },
    { value: "system", label: <Monitor className="size-3.5" aria-hidden="true" />, ariaLabel: t("theme.system") },
    { value: "dark", label: <Moon className="size-3.5" aria-hidden="true" />, ariaLabel: t("theme.dark") },
  ];

  return <SegmentedControl options={options} value={theme} ariaLabel={t("theme.label")} onChange={themeStore.set} />;
}
