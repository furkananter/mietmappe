import { Check, Info, ScanSearch, X } from "lucide-react";
import type { ReactNode } from "react";

import useI18n from "../i18n/useI18n";
import type { Suggestion } from "../types";
import { Button } from "./ui/button";

interface SuggestionBarProps {
  suggestions: Suggestion[];
  wasScanned: boolean;
  onAcceptAll: () => void;
  onDismissAll: () => void;
}

function Note({ children }: { children: ReactNode }) {
  return (
    <p className="flex items-start gap-2 px-1 text-xs text-muted-foreground">
      <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
      {children}
    </p>
  );
}

export default function SuggestionBar({ suggestions, wasScanned, onAcceptAll, onDismissAll }: SuggestionBarProps) {
  const { t } = useI18n();

  if (!wasScanned) return <Note>{t("editor.ocrNote")}</Note>;
  if (suggestions.length === 0) return <Note>{t("editor.noFindings")}</Note>;

  const summary =
    suggestions.length === 1 ? t("editor.findings.one") : t("editor.findings.other", { count: suggestions.length });

  return (
    <div
      className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-finding-border bg-finding-soft p-3"
      role="status"
    >
      <div className="flex min-w-0 items-start gap-2.5">
        <span className="grid size-7 shrink-0 place-items-center rounded-md bg-finding text-background">
          <ScanSearch className="size-4" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-finding">{summary}</p>
          <p className="text-xs text-muted-foreground">{t("editor.suggestionHint")}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={onDismissAll}>
          <X className="size-3.5" aria-hidden="true" />
          {t("editor.dismissAll")}
        </Button>
        <Button variant="ink" size="sm" onClick={onAcceptAll}>
          <Check className="size-3.5" aria-hidden="true" />
          {t("editor.acceptAll")}
        </Button>
      </div>
    </div>
  );
}
