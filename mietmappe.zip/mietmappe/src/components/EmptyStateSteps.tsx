import { FileDown, ScanSearch, Upload } from "lucide-react";

import useI18n from "../i18n/useI18n";
import type { MessageKey } from "../i18n/messages/en";
import cn from "../lib/cn";
import { Card } from "./ui/card";

const STEPS: readonly { icon: typeof Upload; title: MessageKey; text: MessageKey; tone: string }[] = [
  { icon: Upload, title: "empty.step1.title", text: "empty.step1.text", tone: "bg-primary-soft text-primary" },
  { icon: ScanSearch, title: "empty.step2.title", text: "empty.step2.text", tone: "bg-finding-soft text-finding" },
  { icon: FileDown, title: "empty.step3.title", text: "empty.step3.text", tone: "bg-foreground text-background" },
];

export default function EmptyStateSteps() {
  const { t } = useI18n();

  return (
    <ol className="m-0 grid w-full list-none grid-cols-1 gap-3 p-0 sm:grid-cols-3">
      {STEPS.map(({ icon: Icon, title, text, tone }, index) => (
        <li key={title} className="flex">
          <Card className="relative flex w-full flex-col gap-3 p-4 text-left">
            <span className="absolute top-4 right-4 font-mono text-xs text-muted-foreground">0{index + 1}</span>
            <span className={cn("grid size-9 place-items-center rounded-lg", tone)}>
              <Icon className="size-4" aria-hidden="true" />
            </span>
            <div className="flex flex-col gap-1">
              <strong className="text-sm font-semibold">{t(title)}</strong>
              <span className="text-[13px] leading-5 text-muted-foreground">{t(text)}</span>
            </div>
          </Card>
        </li>
      ))}
    </ol>
  );
}
