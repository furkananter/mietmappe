import { TriangleAlert } from "lucide-react";

import describeError from "../i18n/describeError";
import useI18n from "../i18n/useI18n";
import type { AppError } from "../lib/errors";

export default function ErrorText({ error }: { error: AppError }) {
  const { t } = useI18n();

  return (
    <p className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive" role="alert">
      <TriangleAlert className="mt-0.5 size-3.5 shrink-0" aria-hidden="true" />
      <span>{describeError(error, t)}</span>
    </p>
  );
}
