import useI18n from "../i18n/useI18n";
import PanelHeader from "./PanelHeader";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface WatermarkSettingsProps {
  address: string;
  recipient: string;
  previewText: string;
  onAddressChange: (value: string) => void;
  onRecipientChange: (value: string) => void;
}

export default function WatermarkSettings({
  address,
  recipient,
  previewText,
  onAddressChange,
  onRecipientChange,
}: WatermarkSettingsProps) {
  const { t } = useI18n();

  return (
    <section className="flex flex-col gap-4">
      <PanelHeader title={t("watermark.title")} />
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="watermark-address">{t("watermark.address")}</Label>
        <Input
          id="watermark-address"
          value={address}
          placeholder="Musterstraße 12, Berlin"
          onChange={(event) => onAddressChange(event.target.value)}
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="watermark-recipient">{t("watermark.recipient")}</Label>
        <Input
          id="watermark-recipient"
          value={recipient}
          placeholder="Hausverwaltung Beispiel"
          onChange={(event) => onRecipientChange(event.target.value)}
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label>{t("watermark.preview")}</Label>
        <p className="m-0 rounded-lg border bg-muted/60 px-3 py-2.5 font-mono text-xs leading-5 break-words text-muted-foreground">
          {previewText}
        </p>
      </div>
      <p className="m-0 text-xs text-muted-foreground">{t("watermark.note")}</p>
    </section>
  );
}
