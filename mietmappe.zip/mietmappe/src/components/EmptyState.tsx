import { Sparkles, Upload } from "lucide-react";

import useI18n from "../i18n/useI18n";
import EmptyStateSteps from "./EmptyStateSteps";
import FilePickerButton from "./FilePickerButton";
import { BlurReveal } from "./ui/blur-reveal";
import { Button, buttonVariants } from "./ui/button";

interface EmptyStateProps {
  isLoading: boolean;
  onFiles: (files: File[]) => void;
  onLoadSamples: () => void;
}

export default function EmptyState({ isLoading, onFiles, onLoadSamples }: EmptyStateProps) {
  const { t } = useI18n();

  return (
    <section className="relative isolate flex min-h-full flex-col items-center">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-80 bg-grid-fade opacity-60" aria-hidden="true" />
      <div className="flex w-full max-w-3xl flex-col items-center gap-6 px-4 py-14 text-center sm:px-6 sm:py-20">
        <BlurReveal text={t("empty.title")} className="max-w-xl text-balance text-4xl leading-[1.1] font-semibold tracking-tight sm:text-5xl" />
        <p className="max-w-xl text-pretty text-base leading-7 text-muted-foreground">{t("empty.lead")}</p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <FilePickerButton className={`${buttonVariants({ size: "lg" })} cursor-pointer`} disabled={isLoading} onFiles={onFiles}>
            <Upload className="size-4" aria-hidden="true" />
            {t("docs.add")}
          </FilePickerButton>
          <Button variant="outline" size="lg" disabled={isLoading} onClick={onLoadSamples}>
            <Sparkles className="size-4 text-primary" aria-hidden="true" />
            {t("empty.tryDemo")}
          </Button>
        </div>
        <div className="mt-6 w-full">
          <EmptyStateSteps />
        </div>
      </div>
    </section>
  );
}
