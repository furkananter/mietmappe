import { useState } from "react";
import { Check, Eye } from "lucide-react";

import { DOCUMENT_KINDS, REDACTION_GUIDES } from "../guides/redactionGuides";
import useI18n from "../i18n/useI18n";
import type { MessageKey } from "../i18n/messages/en";
import type { DocumentKind, DocumentPage } from "../types";
import PanelHeader from "./PanelHeader";
import { AnimatedCheckbox } from "./ui/animated-checkbox";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface ChecklistPanelProps {
  page: DocumentPage | null;
  onKindChange: (pageId: string, kind: DocumentKind) => void;
}

type CheckedItems = Record<string, Partial<Record<MessageKey, boolean>>>;

export default function ChecklistPanel({ page, onKindChange }: ChecklistPanelProps) {
  const { t } = useI18n();
  const [checked, setChecked] = useState<CheckedItems>({});

  if (!page) {
    return (
      <section className="flex flex-col gap-3">
        <PanelHeader title={t("checklist.title")} />
        <p className="text-sm text-muted-foreground">{t("checklist.noPage")}</p>
      </section>
    );
  }

  const guide = REDACTION_GUIDES[page.kind];
  const pageChecks = checked[page.id] ?? {};
  const toggle = (item: MessageKey) =>
    setChecked((current) => ({ ...current, [page.id]: { ...current[page.id], [item]: !pageChecks[item] } }));
  const changeKind = (value: string) => {
    const next = DOCUMENT_KINDS.find((option) => option === value);
    if (next) onKindChange(page.id, next);
  };

  return (
    <section className="flex flex-col gap-4">
      <PanelHeader title={t("checklist.title")} />
      <div className="flex flex-col gap-1.5">
        <Label>{t("checklist.type")}</Label>
        <Select value={page.kind} onValueChange={changeKind}>
          <SelectTrigger aria-label={t("checklist.type")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {DOCUMENT_KINDS.map((kind) => (
              <SelectItem key={kind} value={kind}>
                {t(`kind.${kind}`)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex flex-col gap-3 rounded-xl border p-3.5">
        <h3 className="flex items-center gap-2 font-mono text-[11px] font-medium tracking-wider text-foreground uppercase">
          <span className="size-2 rounded-xs bg-foreground" aria-hidden="true" />
          {t("checklist.redact")}
        </h3>
        <ul className="m-0 flex list-none flex-col gap-2.5 p-0">
          {guide.redact.map((item) => (
            <li key={item}>
              <AnimatedCheckbox id={`check-${page.id}-${item}`} checked={pageChecks[item] ?? false} onCheckedChange={() => toggle(item)}>
                {t(item)}
              </AnimatedCheckbox>
            </li>
          ))}
        </ul>
      </div>
      <div className="flex flex-col gap-3 rounded-xl border bg-primary-soft/50 p-3.5">
        <h3 className="flex items-center gap-2 font-mono text-[11px] font-medium tracking-wider text-primary uppercase">
          <Eye className="size-3.5" aria-hidden="true" />
          {t("checklist.keep")}
        </h3>
        <ul className="m-0 flex list-none flex-col gap-2 p-0">
          {guide.keep.map((item) => (
            <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
              <Check className="mt-0.5 size-3.5 shrink-0 text-primary" aria-hidden="true" />
              {t(item)}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
