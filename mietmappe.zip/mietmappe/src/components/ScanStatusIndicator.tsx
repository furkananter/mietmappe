import type { ScanStatus } from "../hooks/useSensitiveScan";
import useI18n from "../i18n/useI18n";
import { ShimmerText } from "./ui/shimmer-text";
import { Spinner } from "./ui/spinner";

export default function ScanStatusIndicator({ status }: { status: ScanStatus }) {
  const { t } = useI18n();
  if (status.phase === "idle") return null;
  const label =
    status.phase === "loading"
      ? t("editor.loadingOcr")
      : t("editor.scanning", { current: status.current, total: status.total, percent: Math.round(status.progress * 100) });
  const percent = status.phase === "scanning" ? Math.round(status.progress * 100) : 0;

  return (
    <div className="flex items-center gap-3 text-xs font-medium" role="status">
      <Spinner className="size-3.5 text-finding" />
      <ShimmerText>{label}</ShimmerText>
      <div className="hidden h-1 w-28 overflow-hidden rounded-full bg-muted sm:block" aria-hidden="true">
        <div className="h-full rounded-full bg-finding transition-[width] duration-300" style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}
