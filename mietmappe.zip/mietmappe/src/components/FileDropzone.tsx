import { type DragEvent, useState } from "react";
import { Upload } from "lucide-react";

import useI18n from "../i18n/useI18n";
import cn from "../lib/cn";
import FilePickerButton from "./FilePickerButton";
import { Spinner } from "./ui/spinner";

interface FileDropzoneProps {
  isLoading: boolean;
  onFiles: (files: File[]) => void;
}

export default function FileDropzone({ isLoading, onFiles }: FileDropzoneProps) {
  const { t } = useI18n();
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    onFiles(Array.from(event.dataTransfer.files));
  };

  return (
    <div
      className={cn(
        "rounded-xl border border-dashed bg-muted/40 transition-colors hover:bg-muted",
        isDragging && "border-primary bg-primary-soft",
      )}
      onDragOver={(event) => {
        event.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
    >
      <FilePickerButton
        className="flex cursor-pointer flex-col items-center gap-1 px-3 py-5 text-center aria-disabled:cursor-default"
        disabled={isLoading}
        onFiles={onFiles}
      >
        <span className="mb-1 grid size-9 place-items-center rounded-lg border bg-card text-primary">
          {isLoading ? <Spinner className="size-4" /> : <Upload className="size-4" aria-hidden="true" />}
        </span>
        <strong className="text-[13px] font-medium">{isLoading ? t("docs.processing") : t("docs.add")}</strong>
        <span className="text-xs text-muted-foreground">{t("docs.hint")}</span>
      </FilePickerButton>
    </div>
  );
}
