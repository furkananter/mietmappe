import type { ReactNode } from "react";

interface PanelHeaderProps {
  title: string;
  children?: ReactNode;
}

export default function PanelHeader({ title, children }: PanelHeaderProps) {
  return (
    <div className="flex min-h-7 items-center justify-between gap-2">
      <h2 className="text-sm font-semibold tracking-tight">{title}</h2>
      {children}
    </div>
  );
}
