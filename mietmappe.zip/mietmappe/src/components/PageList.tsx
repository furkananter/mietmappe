import useI18n from "../i18n/useI18n";
import type { DocumentPage, MoveDirection, Suggestion } from "../types";
import PageListItem from "./PageListItem";

interface PageListProps {
  pages: DocumentPage[];
  selectedId: string | null;
  suggestions: Record<string, Suggestion[]>;
  onSelect: (pageId: string) => void;
  onMove: (pageId: string, direction: MoveDirection) => void;
  onRemove: (pageId: string) => void;
}

export default function PageList({ pages, selectedId, suggestions, onSelect, onMove, onRemove }: PageListProps) {
  const { t } = useI18n();
  if (pages.length === 0) return <p className="text-sm text-muted-foreground">{t("docs.empty")}</p>;

  return (
    <ol className="m-0 flex list-none flex-col gap-2 p-0">
      {pages.map((page, index) => (
        <PageListItem
          key={page.id}
          page={page}
          isSelected={page.id === selectedId}
          isFirst={index === 0}
          isLast={index === pages.length - 1}
          pendingSuggestions={suggestions[page.id]?.length ?? 0}
          onSelect={() => onSelect(page.id)}
          onMove={(direction) => onMove(page.id, direction)}
          onRemove={() => onRemove(page.id)}
        />
      ))}
    </ol>
  );
}
