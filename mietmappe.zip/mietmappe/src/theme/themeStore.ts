export type Theme = "light" | "dark" | "system";

const STORAGE_KEY = "mietmappe.theme";
const DARK_QUERY = "(prefers-color-scheme: dark)";
const listeners = new Set<() => void>();

const isTheme = (value: unknown): value is Theme => value === "light" || value === "dark" || value === "system";

function readStored(): Theme {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (isTheme(stored)) return stored;
  } catch {
    return "system";
  }
  return "system";
}

let current: Theme = readStored();

function apply(theme: Theme): void {
  const isDark = theme === "dark" || (theme === "system" && window.matchMedia(DARK_QUERY).matches);
  document.documentElement.classList.toggle("dark", isDark);
}

function notify(): void {
  listeners.forEach((listener) => listener());
}

const themeStore = {
  /** Applies the stored theme and follows OS changes. Call once before first render. */
  init(): void {
    apply(current);
    window.matchMedia(DARK_QUERY).addEventListener("change", () => apply(current));
  },
  set(theme: Theme): void {
    current = theme;
    apply(theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* storage unavailable, keep in memory */
    }
    notify();
  },
  getSnapshot: (): Theme => current,
  subscribe(listener: () => void): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};

export default themeStore;
