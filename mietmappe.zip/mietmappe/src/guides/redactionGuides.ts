import type { MessageKey } from "../i18n/messages/en";
import type { DocumentKind } from "../types";

export interface RedactionGuide {
  redact: readonly MessageKey[];
  keep: readonly MessageKey[];
}

export const DOCUMENT_KINDS: readonly DocumentKind[] = [
  "payslip",
  "residencePermit",
  "idCard",
  "bankStatement",
  "employerLetter",
  "schufa",
  "other",
];

export const REDACTION_GUIDES: Record<DocumentKind, RedactionGuide> = {
  payslip: {
    redact: ["guide.iban", "guide.taxId", "guide.socialSecurity", "guide.religion", "guide.healthInsurance", "guide.personnelNumber"],
    keep: ["guide.keep.name", "guide.keep.employer", "guide.keep.pay", "guide.keep.period"],
  },
  residencePermit: {
    redact: ["guide.can", "guide.mrz", "guide.passportNumber", "guide.cardNumber", "guide.signature"],
    keep: ["guide.keep.name", "guide.keep.validity", "guide.keep.permitType"],
  },
  idCard: {
    redact: ["guide.cardNumber", "guide.can", "guide.mrz", "guide.signature"],
    keep: ["guide.keep.name", "guide.keep.address", "guide.keep.validity"],
  },
  bankStatement: {
    redact: ["guide.accountNumber", "guide.unrelatedTransactions"],
    keep: ["guide.keep.name", "guide.keep.rent"],
  },
  employerLetter: {
    redact: ["guide.personnelNumber", "guide.dateOfBirth"],
    keep: ["guide.keep.name", "guide.keep.employer", "guide.keep.contract", "guide.keep.pay"],
  },
  schufa: {
    redact: ["guide.nothing"],
    keep: ["guide.keep.name", "guide.keep.score", "guide.keep.verification"],
  },
  other: {
    redact: ["guide.anyIds"],
    keep: ["guide.keep.requested"],
  },
};
