import { describe, expect, it } from "vitest";

import { DOCUMENT_KINDS, REDACTION_GUIDES } from "../redactionGuides";
import guessDocumentKind from "../guessDocumentKind";

describe("guessDocumentKind", () => {
  it.each([
    ["Gehaltsabrechnung_09_2026.pdf", "payslip"],
    ["payslip-august.pdf", "payslip"],
    ["eAT_front.jpg", "residencePermit"],
    ["Aufenthaltstitel.png", "residencePermit"],
    ["Reisepass.pdf", "idCard"],
    ["SCHUFA-BonitaetsCheck.pdf", "schufa"],
    ["Kontoauszug_Sept.pdf", "bankStatement"],
    ["Arbeitgeberbestaetigung.pdf", "employerLetter"],
    ["Mietschuldenfreiheitsbescheinigung.pdf", "other"],
    ["IMG_2041.jpg", "other"],
  ])("%s is a %s", (fileName, kind) => {
    expect(guessDocumentKind(fileName)).toBe(kind);
  });

  it("has a guide with items for every kind", () => {
    for (const kind of DOCUMENT_KINDS) {
      expect(REDACTION_GUIDES[kind].redact.length).toBeGreaterThan(0);
      expect(REDACTION_GUIDES[kind].keep.length).toBeGreaterThan(0);
    }
  });
});
