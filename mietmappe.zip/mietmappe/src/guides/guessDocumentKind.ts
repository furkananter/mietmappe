import type { DocumentKind } from "../types";

const RULES: readonly [DocumentKind, RegExp][] = [
  ["other", /mietschulden|meldebescheinigung/i],
  ["payslip", /gehalt|lohn|entgelt|verdienst|payslip|pay[\W_]?slip|salary|bordro/i],
  ["residencePermit", /aufenthalt|residence|(?:^|[\W_])eat(?:[\W_]|$)|niederlassung|blue[\W_]?card|oturum/i],
  ["idCard", /ausweis|reisepass|passport|(?:^|[\W_])pass(?:[\W_]|$)|(?:^|[\W_])id[\W_]?card|kimlik/i],
  ["schufa", /schufa|bonit/i],
  ["bankStatement", /kontoauszug|bank|statement|umsatz|konto/i],
  ["employerLetter", /arbeitgeber|employer|arbeitsvertrag|beschäftigung|bestätigung/i],
];

export default function guessDocumentKind(fileName: string): DocumentKind {
  const match = RULES.find(([, pattern]) => pattern.test(fileName));
  return match ? match[0] : "other";
}
