import guessDocumentKind from "../guides/guessDocumentKind";
import type { DocumentPage } from "../types";
import createId from "./createId";
import { FileProcessingError } from "./errors";
import loadImage from "./loadImage";

export default async function imageFileToPage(file: File): Promise<DocumentPage> {
  const imageUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(imageUrl);
    return {
      id: createId(),
      sourceName: file.name,
      pageNumber: 1,
      imageUrl,
      width: image.naturalWidth,
      height: image.naturalHeight,
      kind: guessDocumentKind(file.name),
      redactions: [],
    };
  } catch (error) {
    URL.revokeObjectURL(imageUrl);
    throw new FileProcessingError(file.name, "image", { cause: error });
  }
}
