const UMLAUTS: Record<string, string> = { ä: "ae", ö: "oe", ü: "ue", ß: "ss" };

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[äöüß]/g, (char) => UMLAUTS[char] ?? char)
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

export default function buildFileName(address: string, date: Date): string {
  const day = date.toISOString().slice(0, 10);
  const slug = slugify(address);
  return slug.length > 0 ? `Bewerbung_${slug}_${day}.pdf` : `Bewerbung_${day}.pdf`;
}
