import type { DocumentPage } from "../types";
import canvasToBlob from "./canvasToBlob";
import drawWatermark from "./drawWatermark";
import loadImage from "./loadImage";

const JPEG_QUALITY = 0.85;

export default async function composePage(page: DocumentPage, watermarkText: string): Promise<Uint8Array> {
  const image = await loadImage(page.imageUrl);
  const canvas = document.createElement("canvas");
  canvas.width = page.width;
  canvas.height = page.height;

  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas 2D context unavailable");

  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, page.width, page.height);
  context.drawImage(image, 0, 0, page.width, page.height);

  context.fillStyle = "#000000";
  for (const rect of page.redactions) {
    context.fillRect(rect.x * page.width, rect.y * page.height, rect.width * page.width, rect.height * page.height);
  }

  if (watermarkText.trim().length > 0) drawWatermark(context, page.width, page.height, watermarkText);

  const blob = await canvasToBlob(canvas, "image/jpeg", JPEG_QUALITY);
  return new Uint8Array(await blob.arrayBuffer());
}
