import type { ApplicationLogEntry } from "../types";

const HEADER = ["Date", "Recipient", "Address", "File", "Documents"];

function escapeCell(value: string): string {
  return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export default function logToCsv(entries: ApplicationLogEntry[]): string {
  const rows = entries.map((entry) => [
    entry.sentAt,
    entry.recipient,
    entry.address,
    entry.fileName,
    entry.documents.join("; "),
  ]);
  return [HEADER, ...rows].map((row) => row.map(escapeCell).join(",")).join("\n");
}
