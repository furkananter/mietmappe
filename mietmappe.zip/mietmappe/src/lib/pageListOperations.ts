import type { DocumentKind, DocumentPage, MoveDirection, Redaction } from "../types";

export function movePage(pages: DocumentPage[], pageId: string, direction: MoveDirection): DocumentPage[] {
  const index = pages.findIndex((page) => page.id === pageId);
  const target = direction === "up" ? index - 1 : index + 1;
  if (index < 0 || target < 0 || target >= pages.length) return pages;
  const next = [...pages];
  const [moved] = next.splice(index, 1);
  if (!moved) return pages;
  next.splice(target, 0, moved);
  return next;
}

function updatePage(
  pages: DocumentPage[],
  pageId: string,
  update: (page: DocumentPage) => DocumentPage,
): DocumentPage[] {
  return pages.map((page) => (page.id === pageId ? update(page) : page));
}

export function addRedactions(pages: DocumentPage[], pageId: string, redactions: Redaction[]): DocumentPage[] {
  if (redactions.length === 0) return pages;
  return updatePage(pages, pageId, (page) => ({ ...page, redactions: [...page.redactions, ...redactions] }));
}

export function removeRedaction(pages: DocumentPage[], pageId: string, redactionId: string): DocumentPage[] {
  return updatePage(pages, pageId, (page) => ({
    ...page,
    redactions: page.redactions.filter((rect) => rect.id !== redactionId),
  }));
}

export function setPageKind(pages: DocumentPage[], pageId: string, kind: DocumentKind): DocumentPage[] {
  return updatePage(pages, pageId, (page) => (page.kind === kind ? page : { ...page, kind }));
}

export function removePageById(pages: DocumentPage[], pageId: string): DocumentPage[] {
  return pages.filter((page) => page.id !== pageId);
}

export function adjacentPageId(pages: DocumentPage[], currentId: string | null, delta: number): string | null {
  if (pages.length === 0) return null;
  const index = pages.findIndex((page) => page.id === currentId);
  const target = index < 0 ? 0 : Math.min(pages.length - 1, Math.max(0, index + delta));
  return pages[target]?.id ?? null;
}

export function uniqueSourceNames(pages: DocumentPage[]): string[] {
  return [...new Set(pages.map((page) => page.sourceName))];
}
