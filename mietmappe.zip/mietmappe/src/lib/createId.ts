export default function createId(): string {
  return crypto.randomUUID();
}
