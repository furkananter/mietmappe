import type { NormalizedRect, Point } from "../types";

const clamp01 = (value: number): number => Math.min(1, Math.max(0, value));

export default function rectFromPoints(start: Point, end: Point): NormalizedRect {
  const left = clamp01(Math.min(start.x, end.x));
  const top = clamp01(Math.min(start.y, end.y));
  const right = clamp01(Math.max(start.x, end.x));
  const bottom = clamp01(Math.max(start.y, end.y));
  return { x: left, y: top, width: right - left, height: bottom - top };
}
