const A4_WIDTH_PT = 595.28;

export interface ComposedImage {
  jpeg: Uint8Array;
  width: number;
  height: number;
}

export default async function buildPdf(images: ComposedImage[]): Promise<Uint8Array> {
  const { PDFDocument } = await import("pdf-lib");
  const pdf = await PDFDocument.create();
  for (const image of images) {
    const embedded = await pdf.embedJpg(image.jpeg);
    const pageHeight = (A4_WIDTH_PT * image.height) / image.width;
    const page = pdf.addPage([A4_WIDTH_PT, pageHeight]);
    page.drawImage(embedded, { x: 0, y: 0, width: A4_WIDTH_PT, height: pageHeight });
  }
  pdf.setProducer("Mietmappe");
  pdf.setCreator("Mietmappe");
  return pdf.save();
}
