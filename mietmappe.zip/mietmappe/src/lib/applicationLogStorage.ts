import type { ApplicationLogEntry } from "../types";
import { StorageError } from "./errors";

const STORAGE_KEY = "mietmappe.applicationLog.v1";

function isLogEntry(value: unknown): value is ApplicationLogEntry {
  if (typeof value !== "object" || value === null) return false;
  const entry = value as Record<string, unknown>;
  return (
    typeof entry.id === "string" &&
    typeof entry.sentAt === "string" &&
    typeof entry.recipient === "string" &&
    typeof entry.address === "string" &&
    typeof entry.fileName === "string" &&
    Array.isArray(entry.documents)
  );
}

export function parseLog(raw: string | null): ApplicationLogEntry[] {
  if (!raw) return [];
  const parsed: unknown = JSON.parse(raw);
  return Array.isArray(parsed) ? parsed.filter(isLogEntry) : [];
}

export function readLog(): ApplicationLogEntry[] {
  try {
    return parseLog(localStorage.getItem(STORAGE_KEY));
  } catch {
    return [];
  }
}

export function writeLog(entries: ApplicationLogEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch (error) {
    throw new StorageError({ cause: error });
  }
}
