export default function buildWatermarkText(address: string, recipient: string, date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const parts = [address.trim(), recipient.trim(), `${month}/${date.getFullYear()}`].filter(
    (part) => part.length > 0,
  );
  return `Nur für Mietbewerbung ${parts.join(", ")}`;
}
