import workerUrl from "pdfjs-dist/legacy/build/pdf.worker.min.mjs?url";

import guessDocumentKind from "../guides/guessDocumentKind";
import type { DocumentPage } from "../types";
import canvasToBlob from "./canvasToBlob";
import createId from "./createId";
import { FileProcessingError } from "./errors";

const RENDER_SCALE = 2;

export default async function renderPdfToPages(file: File): Promise<DocumentPage[]> {
  try {
    const { GlobalWorkerOptions, getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
    GlobalWorkerOptions.workerSrc = workerUrl;
    const data = new Uint8Array(await file.arrayBuffer());
    const pdf = await getDocument({ data }).promise;
    const pages: DocumentPage[] = [];
    const kind = guessDocumentKind(file.name);

    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
      const page = await pdf.getPage(pageNumber);
      const viewport = page.getViewport({ scale: RENDER_SCALE });
      const canvas = document.createElement("canvas");
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);
      await page.render({ canvas, viewport }).promise;
      const blob = await canvasToBlob(canvas, "image/png");
      pages.push({
        id: createId(),
        sourceName: file.name,
        pageNumber,
        imageUrl: URL.createObjectURL(blob),
        width: canvas.width,
        height: canvas.height,
        kind,
        redactions: [],
      });
    }

    await pdf.destroy();
    return pages;
  } catch (error) {
    throw new FileProcessingError(file.name, "pdf", { cause: error });
  }
}
