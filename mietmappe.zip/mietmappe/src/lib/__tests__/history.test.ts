import { describe, expect, it } from "vitest";

import { commit, createHistory, redo, undo } from "../history";
import matchShortcut from "../matchShortcut";
import { adjacentPageId, addRedactions, setPageKind } from "../pageListOperations";
import type { DocumentPage } from "../../types";

const page = (id: string): DocumentPage => ({
  id,
  sourceName: `${id}.pdf`,
  pageNumber: 1,
  imageUrl: "",
  width: 100,
  height: 100,
  kind: "other",
  redactions: [],
});

describe("history", () => {
  it("undoes and redoes commits", () => {
    const start = createHistory(1);
    const twice = commit(commit(start, 2), 3);
    expect(undo(twice).present).toBe(2);
    expect(redo(undo(twice)).present).toBe(3);
    expect(undo(start)).toBe(start);
  });

  it("drops the redo stack on a new commit", () => {
    const branched = commit(undo(commit(createHistory("a"), "b")), "c");
    expect(branched.future).toEqual([]);
    expect(branched.past).toEqual(["a"]);
  });

  it("ignores commits that change nothing", () => {
    const history = createHistory({ value: 1 });
    expect(commit(history, history.present)).toBe(history);
  });
});

describe("matchShortcut", () => {
  const base = { key: "z", metaKey: false, ctrlKey: true, shiftKey: false, isTyping: false };

  it("maps undo and redo", () => {
    expect(matchShortcut(base)).toBe("undo");
    expect(matchShortcut({ ...base, shiftKey: true })).toBe("redo");
    expect(matchShortcut({ ...base, key: "y" })).toBe("redo");
  });

  it("navigates pages without modifiers and ignores typing", () => {
    expect(matchShortcut({ ...base, ctrlKey: false, key: "ArrowDown" })).toBe("nextPage");
    expect(matchShortcut({ ...base, ctrlKey: false, key: "k" })).toBe("previousPage");
    expect(matchShortcut({ ...base, isTyping: true })).toBeNull();
  });
});

describe("page operations", () => {
  const pages = [page("a"), page("b"), page("c")];

  it("finds the adjacent page and clamps at the edges", () => {
    expect(adjacentPageId(pages, "b", 1)).toBe("c");
    expect(adjacentPageId(pages, "c", 1)).toBe("c");
    expect(adjacentPageId(pages, null, 1)).toBe("a");
    expect(adjacentPageId([], "a", 1)).toBeNull();
  });

  it("adds several redactions in one step", () => {
    const rect = { x: 0, y: 0, width: 0.1, height: 0.1 };
    const next = addRedactions(pages, "a", [{ ...rect, id: "1" }, { ...rect, id: "2" }]);
    expect(next[0]?.redactions).toHaveLength(2);
    expect(addRedactions(pages, "a", [])).toBe(pages);
  });

  it("keeps the same object when the kind does not change", () => {
    expect(setPageKind(pages, "a", "other")[0]).toBe(pages[0]);
    expect(setPageKind(pages, "a", "payslip")[0]?.kind).toBe("payslip");
  });
});
