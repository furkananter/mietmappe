import { describe, expect, it } from "vitest";

import { parseLog } from "../applicationLogStorage";
import buildFileName, { slugify } from "../buildFileName";
import buildWatermarkText from "../buildWatermarkText";
import logToCsv from "../logToCsv";
import { movePage } from "../pageListOperations";
import rectFromPoints from "../rectFromPoints";
import type { DocumentPage } from "../../types";

const page = (id: string): DocumentPage => ({
  id,
  sourceName: `${id}.pdf`,
  pageNumber: 1,
  imageUrl: "",
  width: 100,
  height: 100,
  kind: "other",
  redactions: [],
});

describe("rectFromPoints", () => {
  it("normalizes reversed drags and clamps to the page", () => {
    const rect = rectFromPoints({ x: 0.8, y: 0.9 }, { x: 0.2, y: 1.4 });
    expect(rect.x).toBeCloseTo(0.2);
    expect(rect.y).toBeCloseTo(0.9);
    expect(rect.width).toBeCloseTo(0.6);
    expect(rect.height).toBeCloseTo(0.1);
  });
});

describe("buildWatermarkText", () => {
  it("joins address, recipient and month", () => {
    expect(buildWatermarkText(" Hohenzollerndamm 25 ", "Roggenbach", new Date(2026, 8, 24))).toBe(
      "Nur für Mietbewerbung Hohenzollerndamm 25, Roggenbach, 09/2026",
    );
  });

  it("skips empty parts", () => {
    expect(buildWatermarkText("", "", new Date(2026, 0, 1))).toBe("Nur für Mietbewerbung 01/2026");
  });
});

describe("buildFileName", () => {
  it("slugifies umlauts and punctuation", () => {
    expect(slugify("Grolmanstraße 22, Berlin")).toBe("grolmanstrasse_22_berlin");
  });

  it("falls back when address is empty", () => {
    expect(buildFileName("", new Date("2026-09-24T10:00:00Z"))).toBe("Bewerbung_2026-09-24.pdf");
  });
});

describe("movePage", () => {
  it("moves a page and ignores out-of-range moves", () => {
    const pages = [page("a"), page("b"), page("c")];
    expect(movePage(pages, "c", "up").map((p) => p.id)).toEqual(["a", "c", "b"]);
    expect(movePage(pages, "a", "up")).toBe(pages);
  });
});

describe("log serialization", () => {
  it("drops malformed entries", () => {
    const raw = JSON.stringify([{ id: "1" }, { id: "2", sentAt: "x", recipient: "r", address: "a", fileName: "f", documents: [] }]);
    expect(parseLog(raw)).toHaveLength(1);
  });

  it("escapes CSV cells", () => {
    const csv = logToCsv([{ id: "1", sentAt: "2026", recipient: 'A "B"', address: "X, Y", fileName: "f.pdf", documents: ["a", "b"] }]);
    expect(csv.split("\n")[1]).toBe('2026,"A ""B""","X, Y",f.pdf,a; b');
  });
});
