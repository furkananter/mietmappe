import type { DocumentPage } from "../types";
import buildPdf, { type ComposedImage } from "./buildPdf";
import composePage from "./composePage";
import { ExportError } from "./errors";

export default async function exportApplicationPdf(pages: DocumentPage[], watermarkText: string): Promise<Blob> {
  if (pages.length === 0) throw new ExportError("empty");
  try {
    const images: ComposedImage[] = [];
    for (const page of pages) {
      images.push({ jpeg: await composePage(page, watermarkText), width: page.width, height: page.height });
    }
    const bytes = await buildPdf(images);
    return new Blob([new Uint8Array(bytes)], { type: "application/pdf" });
  } catch (error) {
    throw new ExportError("build", { cause: error });
  }
}
