export type FileErrorReason = "unsupported" | "pdf" | "image";
export type ExportErrorReason = "empty" | "build";
export type OcrErrorReason = "load" | "recognize";

export class FileProcessingError extends Error {
  readonly fileName: string;
  readonly reason: FileErrorReason;

  constructor(fileName: string, reason: FileErrorReason, options?: ErrorOptions) {
    super(`${reason}: ${fileName}`, options);
    this.name = "FileProcessingError";
    this.fileName = fileName;
    this.reason = reason;
  }
}

export class ExportError extends Error {
  readonly reason: ExportErrorReason;

  constructor(reason: ExportErrorReason, options?: ErrorOptions) {
    super(`export: ${reason}`, options);
    this.name = "ExportError";
    this.reason = reason;
  }
}

export class StorageError extends Error {
  constructor(options?: ErrorOptions) {
    super("storage: write failed", options);
    this.name = "StorageError";
  }
}

export class OcrError extends Error {
  readonly reason: OcrErrorReason;

  constructor(reason: OcrErrorReason, options?: ErrorOptions) {
    super(`ocr: ${reason}`, options);
    this.name = "OcrError";
    this.reason = reason;
  }
}

export class UnexpectedError extends Error {
  constructor(options?: ErrorOptions) {
    super("unexpected", options);
    this.name = "UnexpectedError";
  }
}

export type AppError = FileProcessingError | ExportError | StorageError | OcrError | UnexpectedError;

export function toAppError(error: unknown): AppError {
  if (
    error instanceof FileProcessingError ||
    error instanceof ExportError ||
    error instanceof StorageError ||
    error instanceof OcrError ||
    error instanceof UnexpectedError
  ) {
    return error;
  }
  return new UnexpectedError({ cause: error });
}
