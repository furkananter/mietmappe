import type { DocumentPage } from "../types";
import { type AppError, FileProcessingError, toAppError } from "./errors";
import imageFileToPage from "./imageFileToPage";
import renderPdfToPages from "./renderPdfToPages";

export interface FilesToPagesResult {
  pages: DocumentPage[];
  errors: AppError[];
}

const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/webp"]);

async function fileToPages(file: File): Promise<DocumentPage[]> {
  if (file.type === "application/pdf") return renderPdfToPages(file);
  if (IMAGE_TYPES.has(file.type)) return [await imageFileToPage(file)];
  throw new FileProcessingError(file.name, "unsupported");
}

export default async function filesToPages(files: File[]): Promise<FilesToPagesResult> {
  const result: FilesToPagesResult = { pages: [], errors: [] };
  for (const file of files) {
    try {
      result.pages.push(...(await fileToPages(file)));
    } catch (error) {
      result.errors.push(toAppError(error));
    }
  }
  return result;
}
