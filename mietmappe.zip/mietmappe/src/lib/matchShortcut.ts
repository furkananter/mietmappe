export type ShortcutAction = "undo" | "redo" | "previousPage" | "nextPage";

export interface KeyInput {
  key: string;
  metaKey: boolean;
  ctrlKey: boolean;
  shiftKey: boolean;
  isTyping: boolean;
}

export default function matchShortcut(input: KeyInput): ShortcutAction | null {
  if (input.isTyping) return null;
  const key = input.key.toLowerCase();
  const modifier = input.metaKey || input.ctrlKey;

  if (modifier && key === "z") return input.shiftKey ? "redo" : "undo";
  if (modifier && key === "y") return "redo";
  if (modifier) return null;
  if (key === "arrowup" || key === "k") return "previousPage";
  if (key === "arrowdown" || key === "j") return "nextPage";
  return null;
}
