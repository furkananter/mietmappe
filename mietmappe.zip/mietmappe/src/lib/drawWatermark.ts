const ANGLE = -Math.PI / 6;
const COLOR = "rgba(70, 70, 70, 0.28)";

export default function drawWatermark(
  context: CanvasRenderingContext2D,
  width: number,
  height: number,
  text: string,
): void {
  const fontSize = Math.round(width / 36);
  const rowGap = fontSize * 5;
  const diagonal = Math.hypot(width, height);

  context.save();
  context.translate(width / 2, height / 2);
  context.rotate(ANGLE);
  context.font = `600 ${fontSize}px sans-serif`;
  context.fillStyle = COLOR;
  context.textAlign = "center";
  context.textBaseline = "middle";

  const textWidth = context.measureText(text).width + fontSize * 3;
  for (let y = -diagonal / 2; y <= diagonal / 2; y += rowGap) {
    const offset = (Math.round(y / rowGap) % 2) * (textWidth / 2);
    for (let x = -diagonal / 2 - offset; x <= diagonal / 2; x += textWidth) {
      context.fillText(text, x, y);
    }
  }
  context.restore();
}
